import { Button } from 'bootstrap';
import React, { Component, useSt } from 'react';
import { Image } from 'react-bootstrap';
import Offcanvas from 'react-bootstrap/Offcanvas'
import OffcanvasHeader from 'react-bootstrap/OffcanvasHeader'

class HeaderComponent extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    render() {
        return (
            <div className="header">
                <header className="text-center">
                    <h1>Online Food Delivering System
                        </h1>
                </header>
            </div>
        );
    }
}
export default HeaderComponent