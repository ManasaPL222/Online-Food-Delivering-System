import React, { Component } from 'react'
import Accordion from 'react-bootstrap/Accordion';


class MainComponent extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div className = "container">
                <br/><br/>
                <Accordion>
                    <Accordion.Item eventKey="0">
                        <Accordion.Header><b> ABOUT</b> </Accordion.Header>
                        <Accordion.Body>
                            <i><b>Online Food Ordering System </b>is the simplest way of enjoying your food at any place and at any time.<br />
                            <b>Customer </b>can directly view restaurants that are available.
                            With easy access and early delivery, you can order food at your finger tips ^ ^
                            <br />
                            Members of<b> Restaurant </b>can easily add their new food items which mainly help them to expand their area of service.
                            What are you waiting for?? <br/>
                            Give us a chance to serve you !!!</i>
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="1">
                        <Accordion.Header><b>LOGIN OPTIONS</b> </Accordion.Header>
                        <Accordion.Body>
                            <button className ="btn btn-primary" onClick={() => this.props.history.push('/custLogin')}>Customer Login</button><br/><br/>
                            <button className ="btn btn-secondary" onClick={() => this.props.history.push('/restLogin')}>Restaurant Login</button>
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="2">
                        <Accordion.Header><b>Contact Us </b> </Accordion.Header>
                        <Accordion.Body>
                            <p>
                                You can directly contact us with a call on <b>** 777771882899 **<br/></b>
                                Or you can simply mail us at <b><a href="www.hexaware.com"> onlinefoodOrdering@hexware.com</a></b>
                            </p>
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="3">
                        <Accordion.Header><b>Report a Problem / FeedBack </b> </Accordion.Header>
                        <Accordion.Body>
                            <a href ='/'> Report</a>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion><br/><br/><br/><br/>
                <h4 className ="text-center">We are happy to serve you at any day and time ^ ^</h4> <br/>
            </div>
        )
    }
}

export default MainComponent