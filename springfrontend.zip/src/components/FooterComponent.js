import React ,{ Component } from 'react';
import { ImFacebook2, ImYoutube2, ImTelegram, ImTwitter} from "react-icons/im";

class FooterComponent extends Component {
    constructor(props){
        super(props);
        this.state = {
           
        }
    }

        render(){
            return(
                <div>
                    <footer className ="footer">
                        <nav>
                          <div>
                                <span className ="text-muted"> All copyrights reserved @Online Food Delivering System <br/>
                                Follow Us on <ImFacebook2/>   <ImYoutube2/>      <ImTelegram/>       <ImTwitter/>
                                </span>
                          </div>
                        </nav>
                    </footer>
                </div>
            );
        }
}

export default FooterComponent