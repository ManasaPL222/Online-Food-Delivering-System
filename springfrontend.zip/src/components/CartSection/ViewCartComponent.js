import React, { Component } from 'react'
import CartService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CartService.js'

class ViewCartComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            cart: [],
            id:this.props.match.params.id,
            restname :this.props.match.params.restname
        }
        this.editCart = this.editCart.bind(this);
        this.deleteCart = this.deleteCart.bind(this);
    }

    componentDidMount() {
        CartService.cartItems().then((res) => {
            this.setState({ cart: res.data });
            console.log(res.data)
        });
    }


    editCart(id) {
        this.props.history.push(`/updateCart/${id}`);
    }
    deleteCart(id) {
        CartService.deleteCartById(id).then(res => {
            this.setState({
                cart: this.state.cart.filter(cart => cart.cartId !== id)
            });
        });
    }

    paymentCart(){
        console.log(this.state.cart)
        this.props.history.push(`/payments/${this.state.id}`);
    }

    cancel(){
        this.props.history.push(`/fooditems/${this.state.restname}/${this.state.id}`);
    }


    // manually controls history of browser and navigates data to other routing path
    render() {
        return (
            <div className = "container"><br/>
                <h4 className="text-center">Your Cart</h4>
                <div className="row">
                    <table className="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th> Food Name</th>
                                <th> Restaurant Name</th>
                                <th> Food Type</th>
                                <th> Food Quantity</th>
                                <th> Food Price </th>
                                <th> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.cart.map(
                                    cart =>
                                        <tr key={cart.cartId}>
                                            <td>{cart.foodName}</td>
                                            <td>{cart.restName}</td>
                                            <td>{cart.foodType}</td>
                                            <td>{cart.foodQuan}</td>
                                            <td>{cart.foodPrice}</td>
                                            <td>
                                                <button onClick={() => this.editCart(cart.cartId)} className="btn btn-success">Edit</button>
                                                <button onClick={() => this.deleteCart(cart.cartId)} className="btn btn-danger">Delete</button>
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <button onClick={()=>this.paymentCart()} className="btn btn-primary">Proceed to Payment</button><hr />

                    <button onClick={() => this.cancel()} className="btn btn-info">Back </button>
                </div> <br/>

            </div>

        )
    }
}

export default ViewCartComponent