import React, { Component } from 'react'
import CartService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CartService.js'
import CustomerService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CustomerService.js'
import { Button } from "react-bootstrap"
import OrderService from '../../services/OrderService'

class PaymentsComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            carts: [],
            cust: [],
            wallet: 0,
            amount: 0,
            a_id: []
        }
    }

    componentDidMount() {
        // wallet for cust purse details
        CustomerService.getCustomerById(this.state.id).then(res => {
            this.setState({ cust: res.data })

            this.setState({ wallet: this.state.cust.wallet })
        });

        CartService.findBycustId(this.state.id).then((res) => {
            this.setState({
                id: this.props.match.params.id,
                carts: res.data
            })
            // console.log(this.state.wallet)
            console.log(this.state.carts)
        });

    }


// on Checkout

    onPayment() {
        var val = 0
        {
            this.state.carts.map((cart) => {
                val = val + cart.foodPrice
            });
        }
        console.log("Total amount " + val)
        this.state.amount = val;
        console.log(this.state.amount)
        console.log("Customer wallet amount " + this.state.cust.wallet)


        if ((this.state.cust.wallet) < val) alert("Your balance is " + this.state.wallet + ". \n Please add amount")
       
// wallet is updated and cart added to order
        else {
            CustomerService.updateWallet(this.state.id, (this.state.wallet) - val).then(res => {
                this.setState({cust:res.data})
                console.log("Remaining Wallet balance " +this.state.cust.wallet)
                alert(" Amount to be paid : " + val + ". \n ")
                alert("Payment Successful\n Remaining Wallet balance " + this.state.cust.wallet);
                this.props.history.push(`/allRests/${this.state.id}`)
            });

// "cartId" "custId" "foodId" "status" in order
            this.state.carts.map(cart=>{
                let order ={
                    cartId:cart.cartId,
                    custId : this.state.id,
                    foodId : cart.foodId,
                    foodName :cart.foodName,
                    restId: cart.restId,
                    price: cart.foodPrice,
                    quan :cart.foodQuan,
                    restName : cart.restName,
                    status : "Ordered"
                }
                console.log('Orders  =>   ' +JSON.stringify(order));
                OrderService.createOrder(order).then(res=>{
                    console.log("From Order :" +res.data)
                })
            });

// deleting from cart
            this.state.carts.map(cart=>{
                let delid = cart.cartId
                console.log('delOrder with id' +delid);
                CartService.deleteCartById(delid).then(res=>{
                    console.log("From Cart deletion " +res.data)
                });
            })

        }
    }

    render() {
        return (
            <div className="container"><br/>
                <h3 className="text-center">Payment </h3><br/>
                <div className="row">
                    <table className="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th> Food Name</th>
                                <th> Food Type </th>
                                <th> Restaurant Name</th>
                                <th> Quantity</th>
                                <th> Price </th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.carts.map(
                                    cart =>
                                        <tr key={cart.cartId}>
                                            <td>{cart.foodName}</td>
                                            <td>{cart.foodType}</td>
                                            <td>{cart.restName}</td>
                                            <td>{cart.foodQuan}</td>
                                            <td>{cart.foodPrice}</td>
                                        </tr>
                                )}
                        </tbody>
                    </table>
                    <Button variant="btn btn-primary" onClick={() => this.onPayment()}>Check Out</Button>
                        <Button variant ="outline-secondary" onClick ={()=>this.props.history.push(`/carts/${this.state.id}`)}>Back</Button>
                </div><br/>
            </div>
        )
    }
}

export default PaymentsComponent