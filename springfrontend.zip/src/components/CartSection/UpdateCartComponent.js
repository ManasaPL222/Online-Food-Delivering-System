import React, { Component } from 'react'
import CartService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CartService.js'


class UpdateCartComponent extends Component {

    constructor(props) {
        super(props);

        this.state = {
            cartId: this.props.match.params.id,
            custId: 0,
            foodId: 0,
            foodName: '',
            restName: '',
            foodType: '',
            foodPrice: 0,
            foodQuan: 0,
            price: 0.0,
            value:0
        }
        this.changeQuantityHandler = this.changeQuantityHandler.bind(this);
    }

    componentDidMount() {
        CartService.getCartById(this.state.cartId).then(res => {
            let cart = res.data;
            console.log("Result Set---->" +cart.foodPrice, cart.foodQuan);
            this.setState(
                {
                    custId: cart.custId,
                    foodId: cart.foodId,
                    foodName: cart.foodName,
                    restName: cart.restName,
                    foodType: cart.foodType,
                    price : cart.foodPrice,
                    foodPrice: cart.foodPrice,
                    foodQuan: cart.foodQuan
                }
            );
        });
    }

    updateCart() {
        // event.preventDefault();
        const res = this.state.price* this.state.foodQuan;
        console.log(res)
        this.state.foodPrice = res;
        // this.setState({foodPrice: res});
        console.log(this.state.foodPrice)
        let upcart = {
            cartId: this.state.cartId,
            custId: this.state.custId,
            foodId: this.state.foodId,
            foodName: this.state.foodName,
            restName: this.state.restName,
            foodType: this.state.foodType,
            foodPrice: this.state.foodPrice,
            foodQuan: this.state.foodQuan,
        }
        console.log("Cart" +this.state.foodPrice)
        console.log('Updated Cart  =>   ' + JSON.stringify(upcart));
        CartService.updateCartById(upcart, this.state.cartId).then(res => {
            this.props.history.push(`/carts/${this.state.custId}`);
        });
    }


    changeQuantityHandler = (event) => {

        this.setState({
            foodQuan: event.target.value
        });
    }


    cancel() {
        this.props.history.push(`/carts/${this.state.custId}`);
    }


    render() {
        return (
            <div>
                <h2 className="text-center">Update Cart</h2>
                <br />
                <div className="container">
                    {
                        <form>
                            <b>
                                <div className="form-group col-sm-4">
                                    <div className="row">
                                        <div className="col">
                                            <label name="foodid">Food Id</label><br />
                                            <input className="form-control" value={this.state.foodId} disabled readOnly /><br />
                                        </div>
                                        <div className="col">
                                            <label name="foodname" >Food Name</label><br />
                                            <input className="form-control" value={this.state.foodName} disabled readOnly /><br />
                                        </div>
                                    </div>
                                    <label name="restname" >Restaurant Name</label><br />
                                    <input className="form-control" value={this.state.restName} disabled readOnly /><br />

                                    <div className="row">
                                        <div className="col">
                                            <label name="foodtype" >Food Type</label><br />
                                            <input className="form-control" value={this.state.foodType} disabled readOnly /><br />
                                        </div>
                                        <div className="col">
                                            <label name="quan">Food Quantity</label>
                                            <input type="number" name="foodQuan" className="form-control"
                                                value={this.state.foodQuan} onChange={this.changeQuantityHandler} />
                                        </div>

                                    </div>
                                    <label name="foodprice">Food Price per(1)</label><br />
                                    <input className="form-control" value={this.state.foodPrice} disabled readOnly /><br />

                                </div></b>
                        </form>
                    }
                    <button className="btn btn-primary" onClick={()=>this.updateCart()}>Change</button>

                    <button className="btn btn-default" onClick={this.cancel.bind(this)}>Back</button>
                </div ><br/>
            </div >
        );
    }
}


export default UpdateCartComponent