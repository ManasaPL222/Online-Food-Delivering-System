import React, { PureComponent } from 'react'
import {Button} from "react-bootstrap"
import FoodItemService from '../../services/FoodItemService';
import RestaurantService from '../../services/RestaurantService';

class AddItemComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            restId : this.props.match.params.id,
            foodName:'',
            foodType:"",
            foodPrice :0.0,
            foodQuan :0
        }
        this.changeNameHandler = this.changeNameHandler.bind(this);
        this.changeTypeHandler = this.changeTypeHandler.bind(this);
        this.changePriceHandler = this.changePriceHandler.bind(this);
        this.changeQuanHandler = this.changeQuanHandler.bind(this);
    }

    componentDidMount(){
        RestaurantService.getRestaurantById(this.state.restId).then((res)=>{
            console.log("Retrieving data from Restaurant "+res.data.restName)
            this.setState({
                restName : res.data.restName
            })
        })
    }

    changeNameHandler =(event)=>{
        this.setState ({
            foodName : event.target.value            
        })
        
    }
    changeTypeHandler =(event) =>{
        this.setState ({
            foodType: event.target.value
        })
    }
    changePriceHandler = (event) =>{
        this.setState({
            foodPrice :event.target.value
        })
    }
    changeQuanHandler =(event) =>{
        this.setState({
            foodQuan :event.target.value
        })
        console.log(this.state.foodName)
        console.log(this.state.foodQuan)
    }

// Main addition of food Items

    addItem =(event)=>{
        if(
            this.state.foodName === "" ||
            this.state.restType === "" ||
            this.state.foodType === "" ||
            this.state.foodQuan === "" ||
            this.state.foodPrice === ""
        ) alert(" Invalid Data")
        else {
        let newItem ={
            restName : this.state.restName,
            foodName : this.state.foodName,
            restId: this.state.restId,
            foodType : this.state.foodType,
            foodQuan :this.state.foodQuan,
            foodPrice : this.state.foodPrice
        }
        console.log("New Item:  " +JSON.stringify(newItem))

        FoodItemService.createFoodItem(newItem).then(res=>{
            alert("Added Successfully !!!");
            this.props.history.push(`/allItems/${this.state.restId}`);
        })
         }
        }

    render() {
        return (
            <div className="container"><br/>
                <h2 className="text-center">Add New Food Item</h2><br/>
                <div className="card container">
                    <div className="card-body">
                        <form>
                            <div className ="row">
                            <div className="form-group col">
                                <label>Food Name</label>
                                <input type="text" placeholder="Enter name" name="foodName" className="form-control"
                                    value={this.state.foodName} onChange={this.changeNameHandler} />
                            </div>
                            <div className="form-group col">
                                <label>Food Type</label>
                                <input type="text" placeholder="Enter type" name="foodType" className="form-control"
                                    value={this.state.foodType} onChange={this.changeTypeHandler} />
                            </div>
                            </div><br/>
                            <div className ="row">
                                <div className ="col">
                                    <label>Food Price</label>
                                    <input type ="decimal" placeholder ="Enter price" name ="foodPrice" className ="form-control"
                                        value ={this.state.foodPrice} onChange ={this.changePriceHandler}/>
                                </div>
                                <div className ="col">
                                <label>Food Quantity</label>
                                    <input type ="number" placeholder ="Enter quantity" name ="foodQuan" className ="form-control"
                                        value ={this.state.foodQuan} onChange ={this.changeQuanHandler}/>
                                </div>
                                <div className ="row">
                                    <div className ='col'> <br/>
                                        <Button variant ="outline-success" onClick ={this.addItem.bind(this)}>Add Item</Button>
                                    </div>
                                    <div className ="col"> <br/>
                                    <Button variant ="outline-default" onClick ={()=>this.props.history.push(`/restHome/${this.state.restId}`)}>Back</Button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        )
    }
}

export default AddItemComponent