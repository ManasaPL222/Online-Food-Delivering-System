import { Button } from 'react-bootstrap'
import React, { PureComponent } from 'react'
import FoodItemService from '../../services/FoodItemService'

class UpdateItemComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            foodItem: [],
            foodId: this.props.match.params.foodId,
            foodName :'',
            foodType: '',
            foodPrice :0.0,
            foodQuan :0
        }
        this.changeNameHandler = this.changeNameHandler.bind(this)
        this.changeTypeHandler = this.changeTypeHandler.bind(this)
        this.changePriceHandler = this.changePriceHandler.bind(this)
        this.changeQuanHandler = this.changeQuanHandler.bind(this)
        console.log(this.state.foodId)
    }

    componentDidMount() {
        FoodItemService.getFoodItemById(this.state.foodId).then((res) => {
            this.setState({ foodItem: res.data })
        });
        this.setState({
            foodName : this.state.foodItem.foodName,
            foodPrice : this.state.foodItem.foodPrice,
            foodType : this.state.foodItem.foodType,
            foodQuan : this.state.foodQuan
        });
    }

    changeNameHandler =(event) =>{
        console.log(this.state.foodItem)
        this.setState({ foodName : event.target.value})
    }
    changeTypeHandler = (event) =>{
        this.setState ({ foodType : event.target.value})
    }
    changePriceHandler = (event) =>{
        this.setState ({ foodPrice : event.target.value})
    }
    changeQuanHandler = (event) =>{
        this.setState ({ foodQuan : event.target.value})
    }

    updItem =(event)=>{
        event.preventDefault();
        let upitem ={
                foodId : this.state.foodId,
                restName : this.state.foodItem.restName,
                restId : this.state.foodItem.restId,
                foodName : this.state.foodName,
                foodType : this.state.foodType,
                foodPrice : this.state.foodPrice,
                foodQuan : this.state.foodQuan
            }
            console.log("Updating Item " +JSON.stringify(upitem))

            FoodItemService.updateFoodItem(upitem,this.state.foodId).then((res)=>{
                this.setState({})
                alert ("Hurrah !!! Updated Successfully.");
            })
            console.log(this.state.foodItem.restId)
            this.props.history.push(`/allItems/${this.state.foodItem.restId}`)
    }
    render() {
        return (
            <div className="container"><br />
                <h2 className="text-center">Update Food Item - {this.state.foodId}</h2><br />
                <div className="card">
                    <div className='card-body'>
                        <form>
                            <div className="row">
                                <div className="form-group col">
                                    <label>Food Name</label>
                                    <input placeholder="Enter food name" name="foodName" className="form-control"
                                        value={this.state.foodName} onChange={this.changeNameHandler} />
                                </div>
                                <div className="form-group col">
                                    <label>Food Type</label>
                                    <input placeholder="Enter food type" name="foodType" className="form-control"
                                        value={this.state.foodType} onChange={this.changeTypeHandler} />
                                </div>
                            </div><br/><br/>
                            <div className ="row">
                                <div className="form-group col">
                                    <label>Food Price</label>
                                    <input placeholder="Enter food price" name="foodPrice" className="form-control"
                                        value={this.state.foodPrice} onChange={this.changePriceHandler} />
                                </div>
                                <div className="form-group col">
                                    <label>Food Quantity</label>
                                    <input placeholder="Enter food quantity" name="foodQuan" className="form-control"
                                        value={this.state.foodQuan} onChange={this.changeQuanHandler} />
                                </div>
                            </div>
                        </form><br/>
                        <div className ="row">
                            <div className ="col">
                        <button className="btn btn-primary" onClick={this.updItem.bind(this)}>Save</button></div>
                        <div className ="col">
                            <button className ="btn bn-secondary" onClick ={()=>this.props.history.push(`/allItems/${this.state.foodItem.restId}`)}>Back</button>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
    )
    }
}

export default UpdateItemComponent