import { Button } from 'react-bootstrap'
import React, { PureComponent } from 'react'
import FoodItemService from '../../services/FoodItemService'
import RestaurantService from '../../services/RestaurantService'

class FoodItemsComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id:this.props.match.params.id,
            items:[]
        }
        this.deleteItem = this.deleteItem.bind(this)
    }

    componentDidMount(){
        console.log(this.state.id)
        FoodItemService.getByrestId(this.state.id).then((res)=>{
            this.setState({
                items: res.data,
            });
        })
    }
    // foodId": 3,"restName": "Tindham","restId": 1,"foodName": "Fried Rice","foodType": "Veg","foodQuan": 1,"foodPrice
    
    updateItem (id){
        console.log(id)
        this.props.history.push(`/updateItem/${id}`)
    }
    

    deleteItem (id){
            FoodItemService.deleteFoodItem(id).then(res => {
                this.setState({
                    items: this.state.items.filter(items => items.foodId !== id)
                });
            });
    }



    render() {
        return (
            <div className ='container'>
                <br/>
                <h2 className = "text-center">Food Items List </h2><br/>
                <div className = "row">
                    <table className ="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th> Food Name</th>
                                <th> Food Type</th>
                                <th> Food Price </th>
                                <th> Food Type</th>
                                <th> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.items.map(
                                    item => 
                                    <tr key = {item.foodId}>
                                        <td>{item.foodName}</td>
                                        <td>{item.foodType}</td>
                                        <td> {item.foodPrice}</td>
                                        <td> {item.foodQuan}</td>
                                        <td>
                                            <div className ="row">
                                            <div className ="col"><Button variant ="outline-info" onClick ={()=> this.updateItem(item.foodId)}>Update</Button> </div>
                                            <div className ="col"><Button variant = "outline-danger" onClick ={()=>this.deleteItem(item.foodId)}>Delete</Button></div>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <div className ="col">
                    <button className ="btn btn-secondary" onClick={()=>{this.props.history.push(`/restHome/${this.state.id}`)}}>Back</button>
                    </div>
                </div>
            </div>
        )
    }
}

export default FoodItemsComponent