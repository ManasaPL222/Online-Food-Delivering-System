import React, { PureComponent } from 'react'
import {Button, Card, CardGroup} from "react-bootstrap"
import { ImProfile } from "react-icons/im";
import {BiFoodMenu , BiLogOut} from "react-icons/bi"
import { MdFastfood} from "react-icons/md";
import {RiLockPasswordLine, RiLogoutBoxRLine} from "react-icons/ri"

class RestaurantHomeComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
        }
    }
    choice(id){
        switch(id){
            case 1:{
                this.props.history.push(`/allItems/${this.state.id}`)// id = restName
                break;}
            case 2:
                this.props.history.push(`/addItem/${this.state.id}`)
                break;
            case 3:
                this.props.history.push(`/restProfile/${this.state.id}`)
                break;
            case 4:
                this.props.history.push(`/restPassword/${this.state.id}`)
                break;
            case 5:
                this.props.history.push(`/acc_rj_Ord/${this.state.id}`)
                break;
            case 6:
                this.props.history.push('/restLogin')
                break;
            
            default:
                this.props.history.push('/PageNotFound')
        }
    }

    render() {
        return (
            <div className =" container">
                <br/>
                <b className ="card">
                <div className="card-body">
                <CardGroup>
                    <Card>
                        <Card.Header className="text-center"><h2>View Food Items </h2></Card.Header>
                        <br/>
                        <Card.Text><p>
                            Food Items of different cuisines from different areas gives you to experience varied tastes.Take your chance of experience
                        </p></Card.Text>
                        <Button variant="outline-primary" onClick={()=> this.choice(1)}>
                        <BiFoodMenu /> View Items</Button><br/>
                        <Card.Footer className="text-muted">2 days ago</Card.Footer>
                    </Card>
                    <br/>
                    <Card>
                        <i><Card.Header className="text-center"><h2>Add Food Items </h2></Card.Header></i>
                        <br/>
                        <Card.Text><p>
                           Add your favourite food items, so that you don't miss tasting it. 
                        </p></Card.Text>
                        <Button variant="outline-success" onClick={()=> this.choice(2)}>
                        <MdFastfood /> Add Items</Button><br/>
                        <Card.Footer className="text-muted">2.5 days ago</Card.Footer>
                    </Card>
                </CardGroup>
                <br/>
                <CardGroup>
                <Card>
                        <Card.Header className="text-center"><h2>Profile </h2></Card.Header>
                        <br/>
                        <Card.Text><p>
                           View your personal details. Get options of updating if any changes.
                        </p></Card.Text>
                        <Button variant="outline-success" onClick={()=> this.choice(3)}>
                        <ImProfile /> Profile </Button><br/>
                        <Card.Footer className="text-muted">2.5 days ago</Card.Footer>
                    </Card>
                    <br/>
                    <Card>
                        <Card.Header className="text-center"><h2>Change Password</h2></Card.Header>
                        <br/>
                        <Card.Text><p>
                            Didn't like your password. <br/> No problem. Simply update your password.
                        </p></Card.Text>
                        <Button variant="outline-secondary" onClick={()=> this.choice(4)}>
                        <RiLockPasswordLine /> Change Password</Button><br/>
                        <Card.Footer className="text-muted">2 days ago</Card.Footer>
                    </Card>
                </CardGroup>
                <CardGroup>
                <Card>
                        <Card.Header className="text-center"><h2>Accept / Reject Orders</h2></Card.Header>
                        <br/>
                        <Card.Text><p>
                          Admin can accept or reject order according to availability of items or their current situation.
                          <br/>
                        </p></Card.Text>
                        <Button variant ="outline-info" onClick={()=> this.choice(5)}>
                        <BiLogOut /> Orders</Button><br/>
                        <Card.Footer className="text-muted">1 day ago</Card.Footer>
                    </Card><br/>
                    <Card>
                        <Card.Header className="text-center"><h2>Log Out</h2></Card.Header>
                        <br/>
                        <Card.Text><p>
                            For logging off. <br/>
                        </p></Card.Text>
                        <Button variant ="outline-danger" onClick={()=> this.choice(6)}>
                        <BiLogOut /> Log Out</Button><br/>
                        <Card.Footer className="text-muted">2 days ago</Card.Footer>
                    </Card>
                </CardGroup>
                </div>
                </b><br/>
            </div>
        )
    }
}

export default RestaurantHomeComponent