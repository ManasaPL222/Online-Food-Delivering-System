import React, { Component } from 'react'
import RestaurantService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/RestaurantService.js'

class ListRestaurantsComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            restaurants : [],
            id:this.props.match.params.id
            
        }
    }

    componentDidMount(){
        console.log(this.state.id)
        RestaurantService.getAllRestaurants().then((res) =>{
            this.setState({restaurants:res.data});
        });
    }
    viewFoodItems(restName){
        this.props.history.push(`/foodItems/${restName}/${this.state.id}`);
    }
    cancel(){
        this.props.history.push(`/custHome/${this.state.id}`);
    }
    // manually controls history of browser and navigates data to other routing path
    render() {
        return (
            <div className ="container"><br/>
                <h2 className = "text-center">Restaurants List </h2><br/>
                <div className = "row">
                    <table className ="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th> Restaurant Name</th>
                                <th> Restaurant Contact Number</th>
                                <th> Restaurant Email Id</th>
                                <th> Restaurant Address</th>
                                <th> View Food Items</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.restaurants.map(
                                    rest => 
                                    <tr key = {rest.restId}>
                                        <td>{rest.restName}</td>
                                        <td>{rest.restContact}</td>
                                        <td>{rest.restEmail}</td>
                                        <td>
                                            {rest.restAddress}
                                            
                                        </td>
                                        <td>
                                            {
                                            <button onClick ={()=>this.viewFoodItems(rest.restName)} className = "btn btn-success">View Food Items</button>
                                            }
                                        </td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
                <button className ="btn btn-danger" onClick ={this.cancel.bind(this)}>Back</button><br/><br/>
            </div>
            
        )
    }
}

export default ListRestaurantsComponent