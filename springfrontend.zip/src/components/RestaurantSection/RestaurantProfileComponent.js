import { Button } from 'react-bootstrap'
import React, { PureComponent } from 'react'
import { BsPersonCircle } from 'react-icons/bs'
import { RiLogoutBoxRLine } from 'react-icons/ri'
import RestaurantService from '../../services/RestaurantService'


class RestaurantProfileComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            restId: this.props.match.params.id,
            rest: []
        }
        console.log(this.state.restId)
    }
    componentDidMount(){
        RestaurantService.getRestaurantById(this.state.restId).then((res) => {
            this.setState({
                rest: res.data
            })
            console.log(this.state.rest)
        })
    }

    /* 
        {
            "restId": 1,
            "restName": "Tindham ",
            "restEmail": "tindam@gmail.com",
            "restContact": 7898564525,
            "restAddress": "Bangalore",
            "password": "po@23"
        } */

    render() {
        return (
            <div className="container"><br />
                <div className="row text-center">
                    <div className="col">
                        <i><h2 className="text-center"><BsPersonCircle /> Restaurant Profile</h2></i>
                    </div>
                    <div className="col"><br/>
                        <Button variant="outline-secondary" onClick={() => this.props.history.push(`/updateRestaurant/${this.state.restId}`)}>Update Profile</Button>
                    </div>
                </div><br />
                {
                    <form>
                        <b className="card">
                            <div className="card-body">
                                <div className="form-group">
                                    <div className="row">
                                        <div className="col">
                                            <label name="restName">Restaurant Name</label><br />
                                            <input className="form-control" value={this.state.rest.restName} disabled readOnly /><br />
                                        </div></div>
                                    <div className="col">
                                        <label name="restEmail">Restaurant Email</label><br />
                                        <input className="form-control" value={this.state.rest.restEmail} disabled readOnly /><br />
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <label name="restPhone">Phone Number</label><br />
                                            <input className="form-control" value={this.state.rest.restContact} disabled readOnly /><br />
                                        </div>
                                        <div className="col">
                                            <label name="restAddress">Address </label><br />
                                            <input className="form-control" value={this.state.rest.restAddress} disabled readOnly /><br />
                                        </div>
                                    </div>
                                </div></div>
                        </b>
                    </form>
                }<br />
                <div className="row">
                    <div className="col">
                        <Button variant="outline-danger" onClick={() => this.props.history.push('/restLogin')}>
                            <RiLogoutBoxRLine /> Log Out
                        </Button></div>
                    <div className="col">
                        <Button variant="outline-secondary" onClick={() => this.props.history.push(`/restHome/${this.state.restId}`)}>
                            Back
                        </Button></div>
                </div><br/>
            </div>
        )
    }
}

export default RestaurantProfileComponent