import { Button } from 'bootstrap'
import React, { PureComponent } from 'react'
import OrderService from '../../services/OrderService'
import RestaurantService from '../../services/RestaurantService'

class AcceptRejectOrdersComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.restId,
            orders:[],
            ordById :[]
        }
    }

    componentDidMount(){
        OrderService.findByrestId(this.state.id).then((res)=>{
            console.log(res.data)
            this.setState({
                orders:res.data
            })
        })
    }
    
    option(id){
        OrderService.getOrderById(id).then(res=>{
            console.log(res.data)
            this.setState({
            //    custId
            })
        })
        console.log(this.state.ordById)
        
        const r = prompt("Type y if you are sure to accept order :" +id +" (y/n)")
        console.log(r)
        if(r.toLowerCase()==='y')
        {

         alert("Accepted order no : " + id)
         let order ={
            status :'Accepted'
        }
        OrderService.updateOrder(order,id).then(res=>{
            this.setState({
                ordById:res.data
            })
        })
        
    }
        else if(r.toLowerCase() === 'n'){
            alert("Rejected order no : " +id)
            let order ={
                status :'Rejected'
            }
            OrderService.updateOrder(order,id).then(res=>{
                this.setState({
                    ordById:res.data
                })
            })
        }
        else alert("Enter valid alphabet")


    }

    
    render() {
        return (
            <div>
                    <div className='row card border-primary'>
                        {
                            this.state.orders.map(
                                order=>
                                <ul key={order.orderId}>
                                <div className ="card">
                                <h5>Food Name : {order.foodName}</h5>
                                <h5>Food Id : {order.foodId}</h5>
                                <h5>Cust Id: {order.custId} </h5>
                                <h5>Order Status : {order.status}</h5>
                                <button className="btn btn-primary" onClick ={()=>this.option(order.orderId)}>Accept / Reject </button>
                                </div></ul>
                            )
                        }
                </div><br/>
            </div>
        )
    }
}

export default AcceptRejectOrdersComponent