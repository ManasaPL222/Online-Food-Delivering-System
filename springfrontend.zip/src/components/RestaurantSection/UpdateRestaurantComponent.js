import react, { Component } from 'react';
import RestaurantService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/RestaurantService.js'

class UpdateRestaurantComponent extends Component{
    constructor(props){
        super(props);
        
        this.state = {
            id : this.props.match.params.id,
            restName :'',
            restEmail :'',
            restAddress :'',
            password:'',
            phone :0
        }
        this.changeNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.changePhoneHandler = this.changePhoneHandler.bind(this);
    }

    componentDidMount(){
        RestaurantService.getRestaurantById(this.state.id).then(res =>{
            let restaurant = res.data;
            console.log(restaurant)
            this.setState(
                {
                    restName:restaurant.restName,
                    restEmail :restaurant.restEmail,
                    restAddress :restaurant.restAddress,
                    phone: restaurant.phone
                }
            );
        });
    }

    updaterestaurant = (event) =>{
        event.preventDefault();
        let restaurant = {
            restName : this.state.custFirstName,
            restEmail : this.state.restEmail,
            restAddress : this.state.restAddress,
            password : this.state.password,
            phone : this.state.phone
        }
        console.log('restaurant  =>   ' +JSON.stringify(restaurant));
        RestaurantService.updateRestaurant(restaurant, this.state.id).then(res=>{
            this.props.history.push(`/profile/${this.state.id}`);
        })
    }


    changeNameHandler = (event) =>{
        this.setState({restName: event.target.value});
    }

    changeEmailHandler =(event) =>{
        this.setState({restEmail: event.target.value});
    }

    changeAddressHandler = (event) =>{
        this.setState({restAddress: event.target.value});
    }
    changePhoneHandler =(event)=>{
        this.setState({ phone : event.target.value});
    }
    
    cancel(){
        this.props.history.push(`/custHome/${this.state.id}`);
    }


    render(){
        return(
            <div>
                <h2 className ="text-center">Update restaurant</h2>
                <br/>
                <div className ="container">
                    <div className ="card col offset-md-3 offset-md-3">
                    <div className = 'card-body'>
                    <form>
                        <div className="form-group">
                            <div className="row">
                            <div className="col">
                            <label>First Name</label>
                            <input placeholder ="Enter first name" name ="custFirstname" className ="form-control"
                            value ={this.state.custFirstName} onChange ={this.changeFirstNameHandler}/>
                        </div>
                        <div className="col">
                            <label>Last Name</label>
                            <input placeholder ="Enter last name" name ="custLastname" className ="form-control" 
                            value ={this.state.custLastName} onChange ={this.changeLastNameHandler}/>
                        </div></div></div>
                        <br/>

                        <div className="row">
                            <div className="col">
                            <label>Email Id</label>
                            <input type ="email" placeholder ="Enter email" name ="custEmail" className ="form-control" 
                            value ={this.state.custEmail} onChange ={this.changeEmailHandler}/>
                            </div>
                            <div className="col">
                            <label>Phone</label>
                            <input type ="phone" placeholder ="Enter phone number" name ="phone" className ="form-control" 
                            value ={this.state.phone} onChange ={this.changePhoneHandler}/>
                            </div>
                            </div>
                        <br/>
                        <div className="form-group">
                            <label>Address </label>
                            <input placeholder ="Enter Address" name ="custAddress" className ="form-control" 
                            value ={this.state.custAddress} onChange ={this.changeAddressHandler}/>
                        </div><br/>

                        <button className ="btn btn-primary" onClick ={this.updaterestaurant.bind(this)}>Update</button>
                        <button className ="btn btn-default" onClick ={this.cancel.bind(this)}>Cancel</button>
                    </form>
                    </div>
                    </div>
                </div><br/>
            </div>
    );
}
}

export default UpdateRestaurantComponent