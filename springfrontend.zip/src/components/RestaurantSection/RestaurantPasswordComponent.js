import React, { PureComponent } from 'react'
import CustomerService from '../../services/CustomerService'
import RestaurantService from '../../services/RestaurantService'

class RestaurantPasswordComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            rest: [],
            presentPwd: '',
            newPwdOne: '',
            newPwdTwo: ''
        }
        this.changePresentHandler = this.changePresentHandler.bind(this)
        this.changePwdOneHandler = this.changePwdOneHandler.bind(this)
        this.changePwdTwoHandler = this.changePwdTwoHandler.bind(this)
    }
    componentDidMount() {
        RestaurantService.getRestaurantById(this.state.id).then((res) => {
            this.setState({
                rest: res.data
            });
            console.log(this.state.rest)
        });
    }

    changePresentHandler = (event) => {
        this.setState({
            presentPwd: event.target.value
        })
    }

    changePwdOneHandler = (e) => {
        this.setState({
            newPwdOne: e.target.value
        });
    }

    changePwdTwoHandler = (e) => {
        this.setState({
            newPwdTwo: e.target.value
        })
        console.log(this.state.presentPwd)
        console.log(this.state.newPwdOne)
        console.log(this.state.newPwdTwo)
    }

    changePwd() {
        if(this.state.presentPwd === ""|| this.state.newPwdOne ==="" || this.state.newPwdTwo === "")alert("Invalid Data")
        if(this.state.newPwdOne !== this.state.newPwdTwo)
            alert("Passwords shouldn't be null or un-equal")

            if (this.state.cust.password !== this.state.presentPwd) {
                alert("Password is incorrect ")
            }
            else {
                let new_rest ={
                    restId : this.state.id,
                    restName : this.state.rest.restName,
                    restAddress : this.state.restAddress,
                    restContact: this.state.restContact,
                    restEmail :this.state.restEmail,
                    password : this.state.newPwdOne
                }
                console.log("New Resta : " +JSON.stringify(new_rest));
                RestaurantService.updateRestaurant(this.state.id,new_rest).then((res) => {
                    this.setState({
                        rest: res.data
                    });
                    console.log("Updated +++++"+ this.state.rest)
                    this.props.history.push(`/restHome/${this.state.id}`)
                })
            }
        }

    render() {
        return (
            <div className="container"><br />
                <h2 className="text-center">Change Password</h2><br />
                <div className="card">
                    <div className="card-body">
                        <form><i>
                            <label>Present Password</label>
                            <input type ="password" placeholder="Enter present one" name="presentPwd" className="form-control"
                                value={this.state.presentPwd} onChange={this.changePresentHandler} />
                            <br />
                            <label>New Password</label>
                            <input type ="password" placeholder="Enter new one" name="newPwdOne" className="form-control"
                                value={this.state.newPwdOne} onChange={this.changePwdOneHandler} />
                            <br />
                            <label>Re-type New Password</label>
                            <input type ="password" placeholder="Re-enter new one" name="newPwdTwo" className="form-control"
                                value={this.state.newPwdTwo} onChange={this.changePwdTwoHandler} />
                            <br />
                            <button className="btn btn-success" onClick={() => this.changePwd().bind(this)}>Update</button>
                        </i>
                        </form>
                    </div>
                </div><br/>

            </div>
        )
    }
}

export default RestaurantPasswordComponent