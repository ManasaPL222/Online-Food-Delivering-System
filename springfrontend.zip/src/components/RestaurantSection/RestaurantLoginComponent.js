import React, { PureComponent } from 'react'
import RestaurantService from '../../services/RestaurantService';
import {Button} from "react-bootstrap"

class RestauarantLoginComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            resta: [],
            email: '',
            pass: '',
            id: 0
        }
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changePasswordHandler = this.changePasswordHandler.bind(this);

    }
    changeEmailHandler = (event) => {
        this.setState({ email: event.target.value });
        console.log("handler " + this.state.email);
    }
    changePasswordHandler = (event) => {
        this.setState({ pass: event.target.value });
        console.log("handler " + this.state.pass);
    }


// Restaurant Login Credentials    
    restLogin = (event) => {

        event.preventDefault();
        if(
            this.state.email === "" || this.state.pass === ""
        ) alert("Invalid Data")
        RestaurantService.findByEmail(this.state.email).then((res) => {
            this.setState({
                resta: res.data,
                id: res.data.restId,
                restName :res.data.restName
            })

            console.log(this.state.resta.password)
            console.log(this.state.restName)
            if (this.state.resta.password === this.state.pass) {
                this.props.history.push(`/restHome/${this.state.id}`);
            }
            else {
                this.props.history.push('/Not Found');
            }
        });
    }

// new restaurant creation mapping
    createrest() {
        this.props.history.push('/createRestaurant')
        
    }

    render() {
        return (
            <div className="container">
                <br />
                <div className="row text-center">
                    <div className="col"> <h3 className="text-left">Restaurant Login</h3></div>
                    <div className="col"><button className="btn btn-primary" onClick={this.createrest.bind(this)}>Create Account</button></div>
                </div>
                <form>
                    <div className="card">
                        <div className="card-body"><i><b>
                            <div className="form-group">
                                <label><b>Email :</b> </label>
                                <input type="email" placeholder="Enter email id" name="email" className="form-control"
                                    value={this.state.email} onChange={this.changeEmailHandler} />
                                <br />
                                <label><b>Password : </b></label>
                                <input type="password" placeholder="Enter password" name="pass" className="form-control"
                                    value={this.state.pass} onChange={this.changePasswordHandler} />
                                <br /> <br />
                            </div>
                            <div className="text-center">
                                <button className="btn btn-success" onClick={this.restLogin.bind(this)}>Login</button>
                            </div></b></i>
                            </div>
                    </div>
                </form><br/>
            </div>
        )
    }
}

export default RestauarantLoginComponent
