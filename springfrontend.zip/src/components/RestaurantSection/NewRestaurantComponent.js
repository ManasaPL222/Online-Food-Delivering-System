import React, { PureComponent } from 'react'
import RestaurantService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/RestaurantService.js'

class NewRestaurantComponent extends PureComponent {
    constructor(props) {
        super(props)

        // String restName, String restEmail, String restAddress,String password, Long phone
        this.state = {
            restaurant:[],
            restName: '',
            restEmail: '',
            restAddress: '',
            restpwdOne: '',
            restpwdTwo: '',
            restPassword: '',
            phone :0
        }
        this.changeNameHandler = this.changeNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.changePasswordHandlerTwo = this.changePasswordHandlerTwo.bind(this);
        this.changePasswordHandlerOne = this.changePasswordHandlerOne.bind(this);
        this.changeContactHandler = this.changeContactHandler.bind(this);
    }
    componentDidMount(){
        RestaurantService.getAllRestaurants().then((res) =>{
            this.setState({restaurant:res.data});
        });
    }

    changeNameHandler = (event) => {
        this.setState({ restName: event.target.value });
    }

    changeEmailHandler = (event) => {
        this.setState({ restEmail: event.target.value });
    }

    changeAddressHandler = (event) => {
        this.setState({ restAddress: event.target.value });
    }

    changePasswordHandlerOne = (event) => {
        this.setState({ restpwdOne: event.target.value });
    }
    changePasswordHandlerTwo = (event) => {
        this.setState({ restpwdTwo: event.target.value });

    }


    changeContactHandler=(e)=>{
        this.setState({ phone : e.target.value});
    }

    saverestaurant = (event) => {
        var found =0;
        // !(this.state.restpwdOne.includes("'0-9','@,$','A-Z','a-z'"))
        event.preventDefault();
        if (this.state.restpwdOne !== this.state.restpwdTwo) { alert('Passwords doesnt match') }

        else 
        // alert("Passwords must match,\n Length should be greater than 8 \n Length should be lesser than 15 ")
        if (
            this.state.restAddress === "" || this.state.restEmail === ""|| this.state.restName === ""|| this.state.restpwdOne=== ""|| this.state.restpwdTwo=== ""
            || this.state.phone === "" ) { alert("Enter invalid details"); }
        else {
            
            this.state.restaurant.map((rest)=>{
                if(rest.restEmail === this.state.restEmail) 
                {
                    alert("Restaurant with this email already exists \n Try with another mail");
                    found = 1;
                    return;
                }
            });
        }
            if(found === 0 && this.state.phone > 6000000000)
            {
            let pwd = this.state.restpwdOne
            console.log(pwd + "  " + this.state.restpwdOne)
            this.state.restPassword = pwd
            let rest = {
                restName: this.state.restName,
                restEmail: this.state.restEmail,
                restAddress: this.state.restAddress,
                password: this.state.restPassword,
                phone : this.state.phone
            }
            console.log('restaurant  =>   ' + JSON.stringify(rest));
            RestaurantService.createRestaurant(rest).then(res => {
                this.props.history.push('/restLogin');
            });
        }
        else alert("Enter correct phone number");
        }

    cancel() {
        this.props.history.push("/restLogin");
    }


    render() {
        return (
            <div>
                <br />
                <h2 className="text-center">Create New Restaurant</h2>
                <b>
                    <div className="container">
                        <div className="card">
                            <div className='card-body'>
                                <form>
                                        <div className="form-group col">
                                            <label>Restaurant Name</label>
                                            <input type="text" placeholder="Enter name" name="restName" className="form-control"
                                                value={this.state.restName} onChange={this.changeNameHandler} />
                                        </div>
                                    <div className="form-group">
                                        <label>Email Id</label>
                                        <input type="email" placeholder="Enter email" name="restEmail" className="form-control"
                                            value={this.state.restEmail} onChange={this.changeEmailHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label>Address </label>
                                        <input type="text" placeholder="Enter Address" name="restAddress" className="form-control"
                                            value={this.state.restAddress} onChange={this.changeAddressHandler} />
                                    </div>
                                    <div className="row">
                                        <div className="form-group col">
                                            <label>Password </label>
                                            <input type="password" placeholder="Enter Password" name="restpwdOne" className="form-control"
                                                value={this.state.restpwdOne} onChange={this.changePasswordHandlerOne} />
                                        </div>
                                        <div className="form-group col">
                                            <label>Re-Enter Password </label>
                                            <input type="password" placeholder="Re-enter Password" name="restpwdTwo" className="form-control"
                                                value={this.state.restpwdTwo} onChange={this.changePasswordHandlerTwo} />
                                        </div></div>
                                        <div className="row">
                                        <div className="form-group col">
                                            <label>Contact </label>
                                            <input type="number" placeholder="Enter Contact Number" name="phone" className="form-control"
                                                value={this.state.phone} onChange={this.changeContactHandler} />
                                        </div>
                                    </div>
                                    <br />
                                    <div className="row text-center">
                                        <span className="col">
                                            <button className="btn btn-primary" onClick={this.saverestaurant.bind(this)}>Save</button></span>
                                        <span className="col">
                                            <button className="btn btn-info" onClick={this.cancel.bind(this)}>Cancel</button> </span></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </b> <br/>
            </div>
        );
    }
}
export default NewRestaurantComponent