import React, { PureComponent } from 'react'
import {Button} from "react-bootstrap"
import { BsPersonCircle } from "react-icons/bs";
import {BiRestaurant, BiHistory} from "react-icons/bi"
import {RiLockPasswordLine, RiLogoutBoxRLine} from "react-icons/ri"

class CustomerHomeComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id
        }
    }
    choice(id){
        switch(id){
            case 1:
                this.props.history.push(`/allRests/${this.state.id}`)
                break;
            case 2:
                this.props.history.push(`/orderHistory/${this.state.id}`)
                break;
            case 3:
                this.props.history.push(`/profile/${this.state.id}`)
                break;
            case 4:
                this.props.history.push(`/password/${this.state.id}`)
                break;
            case 5:
                this.props.history.push('/custLogin')
                break;
            default:
                this.props.history.push('/PageNotFound')
        }
    }

    render() {
        return (
            <div className ="container">
                <br/>
                <b className ="card">
                <div className="card-body">
                <div className ="row text-center">
                <div className ="col">
                <Button variant="outline-primary" onClick={()=> this.choice(1)}>
                <BiRestaurant /> View Restaurants
                </Button></div>
                <div className="col">
                <Button variant="outline-info" onClick={()=> this.choice(2)}>
                <BiHistory /> Order History
                </Button></div>
                <div className="col">
                <Button variant="outline-secondary" onClick={()=> this.choice(3)}>
                <BsPersonCircle /> Profile
                </Button></div></div><br/><br/>
                <div className='row text-center'>
                    <div className="col">
                <Button variant="outline-success" onClick={()=> this.choice(4)}>
                <RiLockPasswordLine /> Change Password
                </Button></div>
                <div className="col">
                <Button variant ="outline-danger" onClick={()=> this.choice(5)}>
                <RiLogoutBoxRLine /> Log Out
                </Button>
                </div></div></div>
                </b><br/>
            </div>
        )
    }
}

export default CustomerHomeComponent