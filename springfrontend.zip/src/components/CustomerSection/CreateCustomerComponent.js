import react, { Component } from 'react';
import CustomerService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CustomerService.js'

class CreateCustomerComponent extends Component{
    constructor(props){
        super(props);
        
        this.state = {
            // id: this.props.match.params.id,
            custFirstName :'',
            custLastName :'',
            custEmail :'',
            custAddress :'',
            phone : 0
        }
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.changePhoneHandler = this.changePhoneHandler.bind(this);
    }

    changeFirstNameHandler = (event) =>{
        this.setState({custFirstName: event.target.value});
    }

    changeLastNameHandler = (event) =>{
        this.setState({custLastName : event.target.value});
    }

    changeEmailHandler =(event) =>{
        this.setState({custEmail: event.target.value});
    }

    changeAddressHandler = (event) =>{
        this.setState({custAddress: event.target.value});
    }

    changePhoneHandler = (event) =>{
        this.setState({phone : event.target.value});
    }

    saveCustomer = (event) =>{
        event.preventDefault();
        let customer = {
            custFirstName : this.state.custFirstName,
            custLastName :this.state.custLastName,
            custEmail : this.state.custEmail,
            custAddress : this.state.custAddress,
            phone : this.state.phone
        }
        console.log('customer  =>   ' +JSON.stringify(customer));
        CustomerService.createCustomer(customer).then(res=>{
            this.props.history.push('/allCustomers');
        })
    }

    cancel(){
        this.props.history.push("/allCustomers");
    }


    render(){
        return(
            <div>
                <h2 className ="text-center">Create New Customer</h2>
                <br/>
                <div className ="container">
                    <div className ="row">
                    <div className ="card col offset-md-3 offset-md-3">
                    <div className = 'card-body'>
                    <form>
                        <div className ="row">
                        <div className="form-group col">
                            <label>First Name</label>
                            <input placeholder ="Enter first name" name ="custFirstname" className ="form-control"
                            value ={this.state.custFirstName} onChange ={this.changeFirstNameHandler}/>
                        </div>
                        <div className="form-group col">
                            <label>Last Name</label>
                            <input placeholder ="Enter last name" name ="custLastname" className ="form-control" 
                            value ={this.state.custLastName} onChange ={this.changeLastNameHandler}/>
                        </div></div><br/>
                        <div className="form-group">
                            <label>Email Id</label>
                            <input type ="email" placeholder ="Enter email" name ="custEmail" className ="form-control" 
                            value ={this.state.custEmail} onChange ={this.changeEmailHandler}/>
                        </div><br/>
                        <div className ="form-group">
                            
                        </div>
                        <div className="form-group">
                            <label>Address </label>
                            <input placeholder ="Enter Address" name ="custAddress" className ="form-control" 
                            value ={this.state.custAddress} onChange ={this.changeAddressHandler}/>
                        </div><br/>

                        <button className ="btn btn-primary" onClick ={this.saveCustomer.bind(this)}>Save</button>
                        <button className ="btn btn-default" onClick ={this.cancel.bind(this)}>Cancel</button>
                    </form>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
    );
}
}

export default CreateCustomerComponent