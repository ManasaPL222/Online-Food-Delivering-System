import { Button } from 'react-bootstrap'
import React, { PureComponent } from 'react'
import { BsPersonCircle } from 'react-icons/bs'
import {RiLogoutBoxRLine} from 'react-icons/ri'
import CustomerService from '../../services/CustomerService'


class CustomerProfileComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            cust: []
        }
    }
    componentDidMount() {
        CustomerService.getCustomerById(this.state.id).then((res) => {
            this.setState({
                cust: res.data
            })
            console.log(this.state.cust)
        })
    }

    render() {
        return (
            <div className="container"><br />
            <div className ="row text-center">
                <div className="col">
                    <i><h2 className="text-center"><BsPersonCircle />  Profile</h2></i>
                </div>
                <div className ="col">
                    <Button variant="outline-secondary" onClick={() => this.props.history.push(`/updateCustomer/${this.state.id}`)}>Update Customer</Button>
                </div>
            </div><br/>
                {
                    <form>
                        <b className="card">
                            <div className="card-body">
                                <div className="form-group">
                                    <div className="row">
                                        <div className="col">
                                            <label name="custfirstName">First Name</label><br />
                                            <input className="form-control" value={this.state.cust.custFirstName} disabled readOnly /><br />
                                        </div></div>
                                    <div className="col">
                                        <label name="custlastName" >Last Name</label><br />
                                        <input className="form-control" value={this.state.cust.custLastName} disabled readOnly /><br />
                                    </div>
                                    <div className="row">
                                        <div className="col">
                                            <label name="custemail">Email Id </label><br />
                                            <input className="form-control" value={this.state.cust.custEmail} disabled readOnly /><br />
                                        </div>
                                        <div className="col">
                                            <label name="custPhone" >Phone Number</label><br />
                                            <input className="form-control" value={this.state.cust.phone} disabled readOnly /><br />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <label name="address">Address </label><br />
                                        <input className="form-control" value={this.state.cust.custAddress} disabled readOnly /><br />
                                    </div>
                                </div></div>
                        </b>
                    </form>
                }<br/>
                <div className="text-align-right">
                <Button variant ="outline-danger" onClick={()=> this.props.history.push('/custLogin')}>
                <RiLogoutBoxRLine /> Log Out
                </Button></div><br/>
            </div>
        )
    }
}

export default CustomerProfileComponent