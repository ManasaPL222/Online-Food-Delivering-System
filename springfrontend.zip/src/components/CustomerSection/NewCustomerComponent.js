import React, { PureComponent } from 'react'
import CustomerService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CustomerService.js'

class NewCustomerComponent extends PureComponent {
    constructor(props) {
        super(props)

        // String custFirstName, String custEmail, String custLastName, String custAddress,String password, Float wallet
        this.state = {
            customers:[],
            custFirstName: '',
            custLastName: '',
            custEmail: '',
            custAddress: '',
            custpwdOne: '',
            custpwdTwo: '',
            custPassword: '',
            custWallet: 0.0,
            phone :0
        }
        this.changeFirstNameHandler = this.changeFirstNameHandler.bind(this);
        this.changeLastNameHandler = this.changeLastNameHandler.bind(this);
        this.changeEmailHandler = this.changeEmailHandler.bind(this);
        this.changeAddressHandler = this.changeAddressHandler.bind(this);
        this.changePasswordHandlerTwo = this.changePasswordHandlerTwo.bind(this);
        this.changePasswordHandlerOne = this.changePasswordHandlerOne.bind(this);
        this.changeContactHandler = this.changeContactHandler.bind(this);
    }
    componentDidMount(){
        CustomerService.getAllCustomers().then((res) =>{
            this.setState({customers:res.data});
        });
    }

    changeFirstNameHandler = (event) => {
        this.setState({ custFirstName: event.target.value });
    }

    changeLastNameHandler = (event) => {
        this.setState({ custLastName: event.target.value });
    }

    changeEmailHandler = (event) => {
        this.setState({ custEmail: event.target.value });
    }

    changeAddressHandler = (event) => {
        this.setState({ custAddress: event.target.value });
    }

    changePasswordHandlerOne = (event) => {
        this.setState({ custpwdOne: event.target.value });
    }
    changePasswordHandlerTwo = (event) => {
        this.setState({ custpwdTwo: event.target.value });

    }

    changeWalletHandler = (event) => {
        this.setState({ custWallet: event.target.value });
    }

    changeContactHandler=(e)=>{
        this.setState({ phone : e.target.value});
    }

    saveCustomer = (event) => {
        var found =0;
        // !(this.state.custpwdOne.includes("'0-9','@,$','A-Z','a-z'"))
        event.preventDefault();
        if (this.state.custpwdOne !== this.state.custpwdTwo) { alert('Passwords doesnt match') }

        else 
        // alert("Passwords must match,\n Length should be greater than 8 \n Length should be lesser than 15 ")
        if (
            this.state.custAddress === ""
            && this.state.custEmail === ''
            && this.state.custFirstName === '') { alert("Enter invalid details"); }
        else {
            
            this.state.customers.map((cust)=>{
                if(cust.custEmail === this.state.custEmail) 
                {
                    alert("Customer with this email already exists \n Try with another mail");
                    found = 1;
                    return;
                }
            });
        }
            if(found === 0 && this.state.phone > 6000000000)
            {
            let pwd = this.state.custpwdOne
            console.log(pwd + "  " + this.state.custpwdOne)
            this.state.custPassword = pwd
            let customer = {
                custFirstName: this.state.custFirstName,
                custLastName: this.state.custLastName,
                custEmail: this.state.custEmail,
                custAddress: this.state.custAddress,
                password: this.state.custPassword,
                wallet: this.state.custWallet,
                phone : this.state.phone
            }
            console.log('customer  =>   ' + JSON.stringify(customer));
            CustomerService.createCustomer(customer).then(res => {
                this.props.history.push('/custLogin');
            });
        }
        else alert("Enter correct phone number");
        }

    cancel() {
        this.props.history.push("/custLogin");
    }


    render() {
        return (
            <div>
                <br />
                <h2 className="text-center">Create New Customer</h2>
                <b>
                    <div className="container">
                        <div className="card">
                            <div className='card-body'>
                                <form>
                                    <div className="row">
                                        <div className="form-group col">
                                            <label>First Name</label>
                                            <input type="text" placeholder="Enter first name" name="custFirstname" className="form-control"
                                                value={this.state.custFirstName} onChange={this.changeFirstNameHandler} />
                                        </div>
                                        <div className="form-group col">
                                            <label>Last Name</label>
                                            <input type="text" placeholder="Enter last name" name="custLastname" className="form-control"
                                                value={this.state.custLastName} onChange={this.changeLastNameHandler} />
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label>Email Id</label>
                                        <input type="email" placeholder="Enter email" name="custEmail" className="form-control"
                                            value={this.state.custEmail} onChange={this.changeEmailHandler} />
                                    </div>
                                    <div className="form-group">
                                        <label>Address </label>
                                        <input type="text" placeholder="Enter Address" name="custAddress" className="form-control"
                                            value={this.state.custAddress} onChange={this.changeAddressHandler} />
                                    </div>
                                    <div className="row">
                                        <div className="form-group col">
                                            <label>Password </label>
                                            <input type="password" placeholder="Enter Password" name="custpwdOne" className="form-control"
                                                value={this.state.custpwdOne} onChange={this.changePasswordHandlerOne} />
                                        </div>
                                        <div className="form-group col">
                                            <label>Re-Enter Password </label>
                                            <input type="password" placeholder="Re-enter Password" name="custpwdTwo" className="form-control"
                                                value={this.state.custpwdTwo} onChange={this.changePasswordHandlerTwo} />
                                        </div></div>
                                        <div className="row">
                                        <div className="form-group col">
                                            <label>Contact </label>
                                            <input type="number" placeholder="Enter Contact Number" name="phone" className="form-control"
                                                value={this.state.phone} onChange={this.changeContactHandler} />
                                        </div>
                                    <div className="form-group col">
                                        <label>Your wallet Balance</label>
                                        <input type="decimal" placeholder="Enter amount" name="wallet" className="form-control"
                                            value={this.state.custWallet} onChange={this.changeWalletHandler} />
                                    </div>
                                    </div>
                                    <br />
                                    <div className="row text-center">
                                        <span className="col">
                                            <button className="btn btn-primary" onClick={this.saveCustomer.bind(this)}>Save</button></span>
                                        <span className="col">
                                            <button className="btn btn-info" onClick={this.cancel.bind(this)}>Cancel</button> </span></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </b>
            </div>
        );
    }
}
export default NewCustomerComponent