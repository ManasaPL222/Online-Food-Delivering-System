import React, { PureComponent } from 'react'
import FoodItemService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/FoodItemService.js'
import CartService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CartService.js'

class FoodItems extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            restname : this.props.match.params.restName,
            id:this.props.match.params.id,
            fooditems :[],
            quan :1
        }
        this.changeQuanHandler = this.changeQuanHandler.bind(this)
    }

    componentDidMount(){
        FoodItemService.getAllFoodItems().then((res) =>{
            console.log(res.data)
            this.setState({fooditems:res.data.filter(fooditems =>fooditems.restName === this.state.restname)}                        
            );
            console.log(this.state.fooditems)
        });
    }
    changeQuanHandler=(event)=>{

        this.setState({quan :event.target.value })
    }

    cancel(){
        this.props.history.push(`/allRests/${this.state.id}`);
    }
    addtoCart(restId,restName,foodId,foodName,foodType,foodPrice,foodQuan){

        let cart = {
            custId: this.state.id,
            foodId : foodId,
            restName : restName,
            foodName : foodName,
            foodType : foodType,
            foodPrice : foodPrice *this.state.quan,
            restId : restId,
            foodQuan : this.state.quan
        }
        console.log('cart  =>   ' +JSON.stringify(cart));
        CartService.insertCart(cart).then(res=>{
            this.props.history.push(`/carts/${this.state.id}`);
        })

    }
    render() {
        return (
            <div className ="container">
                <br/>
                <h2 className = "text-center">Food Items</h2>
                <div className = "row">
                    <table className ="table table-bordered">
                        <thead>
                            <tr>
                                <th> Food Name</th>
                                <th> Food Type</th>
                                <th> Food Price</th>
                                <th> Food Quantity</th>
                                <th> Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.fooditems.map(
                                    food => 
                                    <tr key = {food.foodId}>
                                        <td>{food.foodName}</td>
                                        <td>{food.foodType}</td>
                                        <td>{food.foodPrice}</td>
                                        <td>
                                            <input type="number" name="foodQuan"  onChange={this.changeQuanHandler}/></td>
                                        <td>
                                            <button onClick ={()=>
                                                this.addtoCart(food.restId,food.restName,food.foodId,food.foodName,food.foodType,food.foodPrice,food.foodQuan)} 
                                                className = "btn btn-success">Add to Cart</button>
                                        </td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                    <p>Specially by <b>{this.state.restname}</b> Restaurants </p>
                </div>
                <button className ="btn btn-danger" onClick ={this.cancel.bind(this)}>Back</button><br/><br/>
            </div>
        )
    }

    
}

export default FoodItems