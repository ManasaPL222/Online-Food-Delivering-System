import React, { Component } from 'react'
import CustomerService from 'C:/Users/62000/Desktop/SpringBootSpace/ReactIntegration/springfrontend/src/services/CustomerService.js'
import CreateCustomerComponent from '../CustomerSection/CreateCustomerComponent'
class ListCustomerComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            customers : []
            
        }
        this.addCustomer = this.addCustomer.bind(this);
        this.editCustomer = this.editCustomer.bind(this);
        this.deleteCustomer = this.deleteCustomer.bind(this);
    }

    componentDidMount(){
        CustomerService.getAllCustomers().then((res) =>{
            this.setState({customers:res.data});
        });
    }

    addCustomer(){
        this.props.history.push('/addCustomer');
    }

    editCustomer(id){
        this.props.history.push(`/updateCustomer/${id}`);
    }
    deleteCustomer(id){
        CustomerService.deleteCustomer(id).then(res=>{
            this.setState({customers:this.state.customers.filter(customers=>customers.id!==id)
            });
        });
    }
    // manually controls history of browser and navigates data to other routing path
    render() {
        return (
            <div>
                <h2 className = "text-center">Customers List </h2>
                <div className = "row">
                    <button className ="btn btn-default" onClick ={this.addCustomer}>Add Customer</button>
                    <table className ="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th> Customer First Name</th>
                                <th> Customer Last Name</th>
                                <th> Customer Email Id</th>
                                <th> Customer Address</th>
                                <th> Actions </th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.customers.map(
                                    cust => 
                                    <tr key = {cust.id}>
                                        <td>{cust.custFirstName}</td>
                                        <td>{cust.custLastName}</td>
                                        <td>{cust.custEmail}</td>
                                        <td>{cust.custAddress}</td>
                                        <td>
                                            <button onClick ={()=>this.editCustomer(cust.id)} className = "btn btn-success">Update</button>
                                            <button onClick ={()=>this.deleteCustomer(cust.id)} className = "btn btn-danger">Delete</button>
                                        </td>
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>

            </div>
            
        )
    }
}

export default ListCustomerComponent