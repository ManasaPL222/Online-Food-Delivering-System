import React, { PureComponent } from 'react'
import CustomerService from '../../services/CustomerService'

class ChangePasswordComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            cust: [],
            presentPwd: '',
            newPwdOne: '',
            newPwdTwo: ''
        }
        this.changePresentHandler = this.changePresentHandler.bind(this)
        this.changePwdOneHandler = this.changePwdOneHandler.bind(this)
        this.changePwdTwoHandler = this.changePwdTwoHandler.bind(this)
    }
    componentDidMount() {
        CustomerService.getCustomerById(this.state.id).then((res) => {
            this.setState({
                cust: res.data
            });
            console.log(this.state.cust)
        });
    }

    changePresentHandler = (event) => {
        this.setState({
            presentPwd: event.target.value
        })
    }

    changePwdOneHandler = (e) => {
        this.setState({
            newPwdOne: e.target.value
        });
    }

    changePwdTwoHandler = (e) => {
        this.setState({
            newPwdTwo: e.target.value
        })
        console.log(this.state.presentPwd)
        console.log(this.state.newPwdOne)
        console.log(this.state.newPwdTwo)
    }

    changePwd() {
        if (this.state.newPwdOne !== this.state.newPwdTwo) alert("Passwords shouldn't be null or un-equal")
        if (this.state.presentPwd ==="" || this.state.newPwdOne==="" || this.state.newPwdTwo === "")
            alert("Invalid Data")

            if (this.state.cust.password !== this.state.presentPwd) {
                alert("Password is incorrect ")
            }
            else {
                CustomerService.updatePassword(this.state.id, this.state.newPwdOne).then((res) => {
                    this.setState({
                        cust: res.data
                    });
                    console.log(this.state.cust)
                })
                this.props.history.push(`custHome/${this.state.id}`)
            }
            
        }

    render() {
        return (
            <div className="container"><br />
                <h2 className="text-center">Change Password</h2><br />
                <div className="card">
                    <div className="card-body">
                        <form><i>
                            <label>Present Password</label>
                            <input type ="password" placeholder="Enter present one" name="presentPwd" className="form-control"
                                value={this.state.presentPwd} onChange={this.changePresentHandler} />
                            <br />
                            <label>New Password</label>
                            <input type ="password" placeholder="Enter new one" name="newPwdOne" className="form-control"
                                value={this.state.newPwdOne} onChange={this.changePwdOneHandler} />
                            <br />
                            <label>Re-type New Password</label>
                            <input type ="password" placeholder="Re-enter new one" name="newPwdTwo" className="form-control"
                                value={this.state.newPwdTwo} onChange={this.changePwdTwoHandler} />
                            <br />
                            <button className="btn btn-success" onClick={() => this.changePwd().bind(this)}>Update</button>
                        </i>
                        </form>
                    </div>
                </div>

            </div>
        )
    }
}

export default ChangePasswordComponent