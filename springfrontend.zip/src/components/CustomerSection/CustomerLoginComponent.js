import React, { Component} from 'react'
import CustomerService from '../../services/CustomerService';
import {Button} from "react-bootstrap"

class CustomerLoginComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            cust:'',
            email :'',
            pass :'',
            id:0
        }
        this.changecustEmailHandler = this.changecustEmailHandler.bind(this);
        this.changecustPasswordHandler = this.changecustPasswordHandler.bind(this);
        
    }
    changecustEmailHandler= (event)=>{
        this.setState({email: event.target.value});
        console.log("handler "+this.state.email);
    }
    changecustPasswordHandler = (event) =>{
        this.setState({pass : event.target.value});
        console.log("handler "+this.state.pass);
    }

    
// login validation    
    custLogin=(event)=>{
        event.preventDefault();
        CustomerService.findBycustEmail(this.state.email).then((res)=>{
            this.setState({
                cust: res.data,
                id: res.data.id
            })
            
            console.log(this.state.cust.custEmail)
            console.log(this.state.cust.password)
            if(this.state.email ==="" || this.state.pass ==="") alert("Invalid Data")
            if(this.state.cust.password === this.state.pass ){
                this.props.history.push(`/custHome/${this.state.id}`);
            }
            else{
                this.props.history.push('/Not Found');
            }
        });
    }
    
    render() {
        return (
            <div className ="container">
                <i><b>
                <br/>
                <div className ="row">
                <div className="col text-center"> <h3 className ="text-left">Customer Login</h3></div>
                <div className ="col"><button className ="btn btn-primary" onClick ={()=>this.props.history.push('/create')}>Create Account</button></div>
                </div><br/>
                <div className ="card">
                <div className ="card-body sm">
                    <form>
                    <div className ="row">
                        <div className="form-group">
                            <label>Email : </label>
                            <input type ="email" placeholder ="Enter email id" name ="email" className ="form-control"
                            value ={this.state.email} onChange ={this.changecustEmailHandler}/>
                            <br/>
                            <label>Password :</label>
                            <input type ="password" placeholder ="Enter password" name ="pass" className ="form-control" 
                            value ={this.state.pass} onChange ={this.changecustPasswordHandler}/>
                            <br/> <br/>
                            <div className ="text-center">
                            <Button variant ="outline-success" onClick ={this.custLogin.bind(this)}>Login</Button></div>
                        </div>    
                        </div>
                    </form></div></div>
                    </b></i><br/>
            </div>
        )
    }
}

export default CustomerLoginComponent 
