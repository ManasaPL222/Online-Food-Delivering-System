import React, { PureComponent } from 'react'
import CustomerService from '../../services/CustomerService'
import CartService from '../../services/CartService'
import OrderService from '../../services/OrderService'

class OrderHistoryComponent extends PureComponent {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            orders: [],
            items: [],
            wallet: 0,
            amount: 0.0
        }
    }

    componentDidMount() {
       OrderService.findByCustId(this.state.id).then((res)=>{
        this.setState({
            orders : res.data
        });
        console.log(res.data)
        console.log(this.state.orders)
       }) 
    }
    

    render() {
        return (
            <div className="container"><br/>
            <h3 className="text-center">Order History </h3>
            <div className="row">
                <table className="table table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th> Order Id</th>
                            <th> Food Name</th>
                            <th> Restaurant Name </th>
                            <th> Quantity</th>
                            <th> Price</th>
                            <th> Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.orders.map(
                                ord =>
                                    <tr key={ord.orderId}>
                                        <td>{ord.orderId}</td>
                                        <td>{ord.foodName}</td>
                                        <td>{ord.restName}</td>
                                        <td>{ord.quan}</td>
                                        <td>{ord.price}</td>
                                        <td>{ord.status}</td>
                                    </tr>
                            )}
                    </tbody>
                </table>
                </div>
                </div>
        
        )
    }}
export default OrderHistoryComponent