import './App.css';
import ListCustomerComponent from './components/CustomerSection/ListCustomerComponent'
import {BrowserRouter as Router,
      Route, 
      Switch} from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateCustomerComponent from './components/CustomerSection/CreateCustomerComponent'
import UpdateCustomerComponent from './components/CustomerSection/UpdateCustomerComponent'
import ListRestaurantsComponent from './components/RestaurantSection/ListRestaurantsComponent'
import FoodItems from './components/CustomerSection/FoodItems';
import ViewCartComponent from './components/CartSection/ViewCartComponent';
import UpdateCartComponent from './components/CartSection/UpdateCartComponent';
import PaymentsComponent from './components/CartSection/PaymentsComponent';
import MainComponent from './components/MainComponent';
import CustomerLoginComponent from './components/CustomerSection/CustomerLoginComponent'
import RestaurantLoginComponent from './components/RestaurantSection/RestaurantLoginComponent'
import CustomerHomeComponent from './components/CustomerSection/CustomerHomeComponent'
import RestaurantHomeComponent from './components/RestaurantSection/RestaurantHomeComponent'
import NewCustomerComponent from './components/CustomerSection/NewCustomerComponent';
import OrderHistoryComponent from './components/CustomerSection/OrderHistoryComponent';
import CustomerProfileComponent from './components/CustomerSection/CustomerProfileComponent'; 
import ChangePasswordComponent from './components/CustomerSection/UpdatePasswordComponent';
import NewRestaurantComponent from './components/RestaurantSection/NewRestaurantComponent';
import FoodItemsComponent from './components/FoodSection/FoodItemsComponent';
import AddItemComponent from './components/FoodSection/AddItemComponent';
import UpdateItemComponent from './components/FoodSection/UpdateItemComponent';
import RestaurantProfile from './components/RestaurantSection/RestaurantProfileComponent';
import AcceptRejectOrdersComponent from './components/RestaurantSection/AcceptRejectOrdersComponent';
import RestaurantPasswordComponent from './components/RestaurantSection/RestaurantPasswordComponent';

// exact for loading one component at a time 
// rather than loading all components

function App() {
  
  return (
    <div className ="main">
      <Router>
        <div>
          <HeaderComponent />
          <div className="container">
            <Switch>
              <Route path ="/"  exact component ={MainComponent}></Route>

              <Route path = "/custLogin" component ={CustomerLoginComponent}></Route>
              <Route path = "/restLogin" component ={RestaurantLoginComponent}></Route>
              
              <Route path = "/custHome/:id" component ={CustomerHomeComponent}></Route>
              <Route path = "/create" component ={NewCustomerComponent}></Route>
              <Route path="/allCustomers" component={ListCustomerComponent}  ></Route>
              {/* <Route path="/addCustomer" component={CreateCustomerComponent}  ></Route> */}
              <Route path = "/profile/:id" component ={CustomerProfileComponent}></Route>
              <Route path="/updateCustomer/:id" component={UpdateCustomerComponent}  ></Route>
              <Route path = "/orderHistory/:id" component ={OrderHistoryComponent}></Route>
              <Route path = "/password/:id" component ={ChangePasswordComponent}></Route>
              
              <Route path ="/createRestaurant" component ={NewRestaurantComponent}></Route>
              <Route path = "/restHome/:id" component ={RestaurantHomeComponent}></Route>
              <Route path ="/allRests/:id" component ={ListRestaurantsComponent} ></Route>
              
              <Route path ="/foodItems/:restName/:id" component ={FoodItems}></Route>
              
              <Route path ="/carts/:id" component ={ViewCartComponent}></Route>
              <Route path ="/updateCart/:id" component ={UpdateCartComponent}></Route>
              
              <Route path ="/payments/:id" component ={PaymentsComponent}></Route>

              <Route path ="/allItems/:id" component ={FoodItemsComponent}></Route>
              <Route path ="/addItem/:id" component ={AddItemComponent}></Route>
              <Route path = "/updateItem/:foodId" component ={UpdateItemComponent}></Route>
              <Route path = "/restProfile/:id" component = {RestaurantProfile}></Route>
              <Route path ="/acc_rj_Ord/:restId" component ={AcceptRejectOrdersComponent}></Route>
              <Route path ="/restPassword/:id" component ={RestaurantPasswordComponent}></Route>
            </Switch>
          </div>
          {/* <FooterComponent /> */}
        </div>
      </Router>
    </div>
  );
}

export default App;