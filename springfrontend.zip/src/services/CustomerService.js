import axios from 'axios';

class CustomerService {

    getAllCustomers(){
        return axios.get("http://localhost:9897/allcustomers");
    }

    createCustomer(customer){
        return axios.post("http://localhost:9897/newcustomer", customer);
    }
    getCustomerById(customerId){
        return axios.get("http://localhost:9897/customer/" +customerId);
    }

    deleteCustomer(customerId){
        return axios.delete("http://localhost:9897/delcustomer/" +customerId);
    }

    updateCustomer(customer, customerId){
        return axios.put("http://localhost:9897/updcustomer/" +customerId, customer);
    }

    findBycustEmail(custEmail){
        return axios.get("http://localhost:9897/findcustEmail/" +custEmail);
    }

    updateWallet(custId,wallet){
        return axios.put("http://localhost:9897/updwallet/" +custId+'/'+wallet);
    }
    updatePassword(custId,pwd){
        return axios.put("http://localhost:9897/updPwd/" +custId +"/" + pwd);
    }
}

export default new CustomerService();