import axios from 'axios';

class RestaurantService {

    getAllRestaurants(){
        return axios.get("http://localhost:9897/allrestaurants");
    }

    createRestaurant(restaurant){
        return axios.post("http://localhost:9897/newrestaurant", restaurant);
    }
    getRestaurantById(restaurantId){
        return axios.get("http://localhost:9897/restaurant/" +restaurantId);
    }

    deleteRestaurant(restaurantId){
        return axios.delete("http://localhost:9897/delrestaurant/" +restaurantId);
    }

    updateRestaurant(restaurant, restaurantId){
        return axios.put("http://localhost:9897/updrestaurant/" +restaurantId, restaurant);
    }

    findByEmail(restEmail){
        return axios.get("http://localhost:9897/findbyemail/" +restEmail);
    }
}

export default new RestaurantService();