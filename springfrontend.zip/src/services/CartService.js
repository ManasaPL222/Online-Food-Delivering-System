import axios from 'axios';

class CartService {

    insertCart(cart){
        return axios.post("http://localhost:9897/insertcart",cart);
    }
    
    cartItems(){
        return axios.get("http://localhost:9897/allcarts");
    }

    getCartById(cartId){
        return axios.get("http://localhost:9897/cart/" +cartId);
    }

    deleteCartById(cartId){
        return axios.delete("http://localhost:9897/delcart/" +cartId);
    }

    updateCartById(cart, cartId){
        return axios.put("http://localhost:9897/updcart/" +cartId, cart);
    }
    findBycustId(custId){
        return axios.get("http://localhost:9897/findBycustId/" +custId);
    }
}

export default new CartService();