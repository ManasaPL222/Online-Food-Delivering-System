import axios from 'axios';

class FoodItemService {

    getAllFoodItems(){
        return axios.get("http://localhost:9897/allfooditem");
    }

    createFoodItem(fooditem){
        return axios.post("http://localhost:9897/newfooditem", fooditem);
    }
    getFoodItemById(foodId){
        return axios.get("http://localhost:9897/fooditem/" +foodId);
    }

    deleteFoodItem(foodId){
        return axios.delete("http://localhost:9897/delfooditem/" +foodId);
    }

    updateFoodItem(foodItem, foodId){
        return axios.put("http://localhost:9897/updfooditem/" +foodId, foodItem);
    }

    getByrestId(restId){
        return axios.get("http://localhost:9897/restId/" +restId);
    }
}

export default new FoodItemService();