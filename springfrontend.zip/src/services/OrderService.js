import axios from 'axios';

class OrderService {

    getAllOrders(){
        return axios.get("http://localhost:9897/allOrders");
    }

    createOrder(newOrder){
        return axios.post("http://localhost:9897/newOrder", newOrder);
    }

    getOrderById(ordId){
        return axios.get("http://localhost:9897/order/" +ordId);
    }

    deleteOrder(ordId){
        return axios.delete("http://localhost:9897/delOrder/" +ordId);
    }

    updateOrder(order, ordId){
        return axios.put("http://localhost:9897/updOrder/" +ordId, order);
    }

    findByCustId(id){
        return axios.get("http://localhost:9897/ordCustId/" +id);
    }

    findByrestId(id){
        return axios.get("http://localhost:9897/ordresId/" +id);
        
    }
}

export default new OrderService();