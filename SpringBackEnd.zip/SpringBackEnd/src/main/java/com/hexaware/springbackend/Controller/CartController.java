package com.hexaware.springbackend.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.springbackend.entity.Cart;
import com.hexaware.springbackend.exception.CartNotFoundException;
import com.hexaware.springbackend.service.CartService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class CartController {

	@Autowired
	private CartService cartService;
	
	@PostMapping(consumes = "application/json", produces = "application/json", path = "/insertcart")
	public Cart insertintoCart(@RequestBody Cart newcart){
		
		return cartService.insertCart(newcart);
		}
	
	@GetMapping(path = "/cart/{cartId}",produces = "application/json")
	public ResponseEntity<Cart>getCartById(@PathVariable(value = "cartId") Long cartId){
	 
	return cartService.getCartById(cartId); }
	
	
	@GetMapping("/allcarts")
	public List<Cart> cartItems() {
		return cartService.cartItems();
	}

	@DeleteMapping("/delcart/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteCartById(@PathVariable("id")  Long cartId) throws CartNotFoundException {
		return cartService.deleteCartById(cartId);
	}

	@PutMapping("/updcart/{id}")
	public ResponseEntity<Cart> updateCart(@RequestBody Cart updatecart,
								@PathVariable("id") Long cartid) throws CartNotFoundException {
	
		return cartService.updateCart(updatecart, cartid);
	}
	
	@GetMapping("/findBycustId/{id}")
	public List<Cart> findBycustId(@PathVariable("id") Long custId) throws CartNotFoundException{
		return cartService.findBycustId(custId);
	}
	
}
