package com.hexaware.springbackend.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hexaware.springbackend.entity.FoodItems;
import com.hexaware.springbackend.exception.FoodItemNotFoundException;
import com.hexaware.springbackend.service.FoodItemService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class FoodItemsController {

	@Autowired
	private FoodItemService foodService;
	
	@PostMapping(consumes = "application/json", produces = "application/json", path = "/newfooditem")
	public FoodItems createFoodItem(@RequestBody FoodItems food){
		
		return foodService.createFoodItem(food);
		}
	
	
	@GetMapping(path = "/fooditem/{foodId}",produces = "application/json")
	public ResponseEntity<FoodItems>getFoodItemById(@PathVariable(value = "foodId") Long foodId){
	
		return foodService.getFoodItemById(foodId);				
	}
	
	@GetMapping("/allfooditem")
	public List<FoodItems> getAllFoodItems() {
		return foodService.getAllFoodItems();
	}

	@DeleteMapping("/delfooditem/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(@PathVariable("id")  Long foodId) throws FoodItemNotFoundException {
		return foodService.deleteFoodItem(foodId);
	}

	@PutMapping("/updfooditem/{id}")
	public ResponseEntity<FoodItems> updateFoodItem(@RequestBody FoodItems updatefoodItem,
								@PathVariable("id") Long foodid) throws FoodItemNotFoundException {
	
		return foodService.updateFoodItem(updatefoodItem, foodid);
	}
	
	@GetMapping(path = "/restId/{restId}",produces = "application/json")
	public List<FoodItems> findByrestId(@PathVariable(value = "restId") Long id){
	
		return foodService.findByrestId(id);				
	}
}
