package com.hexaware.springbackend.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long cartId;
	
	@Column(name ="custId")
	private Long custId;
	
	@Column(name ="foodId")
	private Long foodId;
	
	@Column (name ="restName")
	private String restName;
	
	@Column(name ="restId")
	private Long restId;
	
	public Long getRestId() {
		return restId;
	}

	public void setRestId(Long restId) {
		this.restId = restId;
	}

	@Column (name ="foodName")
	private String foodName;
	
	@Column (name ="foodType")
	private String foodType;
	
	@Column (name ="foodPrice")
	private Float foodPrice;
	
	@Column(name ="foodQuan")
	private String foodQuan;

	
	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	public Long getFoodId() {
		return foodId;
	}

	public void setFoodId(Long foodId) {
		this.foodId = foodId;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public Float getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(Float foodPrice) {
		this.foodPrice = foodPrice;
	}

	public String getFoodQuan() {
		return foodQuan;
	}

	public void setFoodQuan(String foodQuan) {
		this.foodQuan = foodQuan;
	}

	public Cart(Long restId,Long cartId,Long custId, Long foodId, String restName, String foodName, String foodType, Float foodPrice,
			String foodQuan) {
		super();
		this.cartId = cartId;
		this.foodId = foodId;
		this.restName = restName;
		this.foodName = foodName;
		this.foodType = foodType;
		this.foodPrice = foodPrice;
		this.foodQuan = foodQuan;
	}

	public Cart(Long custId,Long foodId, String restName, String foodName, String foodType, Float foodPrice, String foodQuan) {
		super();
		this.custId = custId;
		this.foodId = foodId;
		this.restName = restName;
		this.foodName = foodName;
		this.foodType = foodType;
		this.foodPrice = foodPrice;
		this.foodQuan = foodQuan;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
