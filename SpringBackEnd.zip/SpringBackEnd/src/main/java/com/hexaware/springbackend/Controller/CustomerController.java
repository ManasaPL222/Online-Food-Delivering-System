package com.hexaware.springbackend.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.springbackend.entity.Customer;
import com.hexaware.springbackend.exception.CustomerNotFoundException;
import com.hexaware.springbackend.service.CustomerService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class CustomerController {

	@Autowired
	private CustomerService custService;
	
	@PostMapping(consumes = "application/json", produces = "application/json", path = "/newcustomer")
	public Customer createCustomer(@RequestBody Customer cust){
		
		return custService.createCustomer(cust);
		}
	
	
	@GetMapping(path = "/customer/{custId}",produces = "application/json")
	public ResponseEntity<Customer>getCustomerById(@PathVariable(value = "custId") Long custId){
	
		return custService.getCustomerById(custId);				
	}
	
	@GetMapping("/allcustomers")
	public List<Customer> getAllCustomers() {
		return custService.getAllCustomers();
	}

	@DeleteMapping("/delcustomer/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteCustomer(@PathVariable("id")  Long custId) throws CustomerNotFoundException {
		return custService.deleteCustomer(custId);
	}

	@PutMapping("/updcustomer/{id}")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer updateCustomer,
								@PathVariable("id") Long id) throws CustomerNotFoundException {
	
		return custService.updateCustomer(updateCustomer, id);
	}
	
	// Customer Login Validation --------
	@GetMapping("/findcustEmail/{email}")
	public ResponseEntity<Customer> loginCustomer(@PathVariable(value = "email") String email)throws CustomerNotFoundException {
			return custService.loginCustomer(email);
		}
	
	@PutMapping("/updwallet/{id}/{wal}")
	public ResponseEntity<Customer> updateWallet(@PathVariable("id") Long id, @PathVariable("wal") Float wallet) throws CustomerNotFoundException {
	
		return custService.updateWallet(id,wallet);
	}
	
	@PutMapping("/updPwd/{id}/{pwd}")
	public ResponseEntity<Customer> updatePassword(@PathVariable("id") Long id, @PathVariable("pwd") String pwd) throws CustomerNotFoundException {
		
		return custService.updatePwd(id,pwd);
	}
}
