package com.hexaware.springbackend.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import com.hexaware.springbackend.entity.Restaurant;
import com.hexaware.springbackend.exception.RestaurantNotFoundException;

public interface RestaurantService {
	
	List<Restaurant> getAllRestaurants();
	
	Restaurant createRestaurant(Restaurant newRestaurant);

	public ResponseEntity<Restaurant> getRestaurantById(Long restId) throws RestaurantNotFoundException;
	
	// login
	ResponseEntity<Restaurant>  loginRestaurant(String email)throws RestaurantNotFoundException;

	ResponseEntity<Map<String,Boolean>>  deleteRestaurant(Long restId)throws RestaurantNotFoundException;

	ResponseEntity<Restaurant>  updateRestaurant(Restaurant newRestaurant, Long id) throws RestaurantNotFoundException;

	Optional<Restaurant> findByrestEmail(String email) throws RestaurantNotFoundException;

}
