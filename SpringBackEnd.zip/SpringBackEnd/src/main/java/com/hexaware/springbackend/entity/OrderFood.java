package com.hexaware.springbackend.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderFood {
	
	public OrderFood() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	
	@Column(name ="cartId")
	private Long cartId;
	
	@Column(name ="custId")
	private Long custId;
	
	@Column(name ="foodId")
	private Long foodId;
	
	@Column(name="status")
	private String status;
	
	@Column(name ="foodName")
	private String foodName;
	
	@Column(name = "price")
	private Float price;
	
	@Column(name ="quan")
	private Long quan;
	
	@Column(name ="restId")
	private Long restId;
	
	public Long getRestId() {
		return restId;
	}

	public void setRestId(Long restId) {
		this.restId = restId;
	}
	@Column(name ="restName")
	private String restName;

	public OrderFood(Long restId,Long orderId, Long cartId, Long custId, Long foodId, String restName, String status, String foodName, Float price,
			Long quan) {
		super();
		this.restId = restId;
		this.restName = restName;
		this.orderId = orderId;
		this.cartId = cartId;
		this.custId = custId;
		this.foodId = foodId;
		this.status = status;
		this.foodName = foodName;
		this.price = price;
		this.quan = quan;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Long getQuan() {
		return quan;
	}

	public void setQuan(Long quan) {
		this.quan = quan;
	}

	public Long getOrderId() {
		return orderId;
	}

	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getCartId() {
		return cartId;
	}

	public void setCartId(Long cartId) {
		this.cartId = cartId;
	}

	public Long getFoodId() {
		return foodId;
	}

	public void setFoodId(Long foodId) {
		this.foodId = foodId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OrderFood(Long orderId, Long cartId, Long foodId, String status) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.foodId = foodId;
		this.status = status;
	}

	public OrderFood(Long orderId) {
		super();
		this.orderId = orderId;
	}

	public OrderFood(Long orderId, Long cartId, Long custId, Long foodId, String status) {
		super();
		this.orderId = orderId;
		this.cartId = cartId;
		this.custId = custId;
		this.foodId = foodId;
		this.status = status;
	}
	
	
}
