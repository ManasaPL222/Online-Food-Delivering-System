package com.hexaware.springbackend.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hexaware.springbackend.entity.Restaurant;
import com.hexaware.springbackend.exception.RestaurantNotFoundException;
import com.hexaware.springbackend.service.RestaurantService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class RestaurantController {

	@Autowired
	private RestaurantService restService;
	
	@PostMapping(consumes = "application/json", produces = "application/json", path = "/newrestaurant")
	public Restaurant createRestaurant(@RequestBody Restaurant rest){
		
		return restService.createRestaurant(rest);
		}
	
	
	@GetMapping(path = "/restaurant/{restId}",produces = "application/json")
	public ResponseEntity<Restaurant>getRestaurantById(@PathVariable(value = "restId") Long restId){
	
		return restService.getRestaurantById(restId);				
	}
	
	@GetMapping("/allrestaurants")
	public List<Restaurant> getAllRestaurant() {
		return restService.getAllRestaurants();
	}

	@DeleteMapping("/delrestaurant/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteRestaurant(@PathVariable("id")  Long restId) throws RestaurantNotFoundException {
		return restService.deleteRestaurant(restId);
	}

	@PutMapping("/updrestaurant/{id}")
	public ResponseEntity<Restaurant> updateRestaurant(@RequestBody Restaurant updateRestaurant,
								@PathVariable Long id) throws RestaurantNotFoundException {
	
		return restService.updateRestaurant(updateRestaurant, id);
	}
	

	// Restaurant Login Validation --------
	@GetMapping(path = "/findbyemail/{email}", produces = "application/json")
	public ResponseEntity<Restaurant> loginRestaurant(@PathVariable(value = "email") String email)throws RestaurantNotFoundException {
		return restService.loginRestaurant(email);
	}
	
}
