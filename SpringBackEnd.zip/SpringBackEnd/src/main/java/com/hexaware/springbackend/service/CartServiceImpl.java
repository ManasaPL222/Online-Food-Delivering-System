package com.hexaware.springbackend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.hexaware.springbackend.entity.Cart;
import com.hexaware.springbackend.exception.CartNotFoundException;
import com.hexaware.springbackend.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	private CartRepository cartRepo;

	@Override
	public List<Cart> cartItems() {
		// TODO Auto-generated method stub
		return cartRepo.findAll();
	}
	
	

	@Override
	public Cart insertCart(Cart newCart) {
		// TODO Auto-generated method stub
		return cartRepo.save(newCart);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteCartById(Long cartId) throws CartNotFoundException {
		// TODO Auto-generated method stub
		Cart delCart = cartRepo.findById(cartId)
				.orElseThrow(() -> new CartNotFoundException("Cart does not exist with id = " + cartId));
		cartRepo.delete(delCart);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);

	}

	@Override
	public ResponseEntity<Cart> updateCart(Cart updateCart, Long id) throws CartNotFoundException {
		// TODO Auto-generated method stub
		Cart cart = cartRepo.findById(id).
				orElseThrow(() -> new CartNotFoundException("Cart does not exist with id = " + id));
		cart.setFoodQuan(updateCart.getFoodQuan());
		cart.setRestName(updateCart.getRestName());
		cart.setCartId(updateCart.getCartId());
		cart.setFoodName(updateCart.getFoodName());
		cart.setFoodId(updateCart.getFoodId());
		cart.setFoodPrice(updateCart.getFoodPrice());
		cart.setFoodType(updateCart.getFoodType());
		cart.setCustId(updateCart.getCustId());
		cart.setRestId(updateCart.getRestId());
		Cart updatedCart = cartRepo.save(cart);
		return ResponseEntity.ok(updatedCart);

	}
	
	@Override
	public ResponseEntity<Cart> getCartById(Long cartId) throws CartNotFoundException {
		// TODO Auto-generated method stub
		Cart cart = cartRepo.findById(cartId).orElseThrow(()-> new CartNotFoundException("Cart Not Found with id: " +cartId));
		return ResponseEntity.ok(cart);
	}



	@Override
	public List<Cart> findBycustId(Long custId) throws CartNotFoundException {
		// TODO Auto-generated method stub
		return cartRepo.findBycustId(custId);
	}
}