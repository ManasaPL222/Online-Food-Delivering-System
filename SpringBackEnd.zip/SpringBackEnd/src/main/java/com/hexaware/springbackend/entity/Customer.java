package com.hexaware.springbackend.entity;

import javax.persistence.Entity;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	public Customer() {
			super();
			// TODO Auto-generated constructor stub
		}
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long id;
		
		@Column(name = "custFirstName")
		private String custFirstName;
		
		@Column(name = "custEmail")
		private String custEmail;
		
		@Column (name ="custLastName")
		private String custLastName;
		
		@Column (name = "custAddress")
		private String custAddress;
		
		@Column(name ="password")
		private String password;
		
		@Column(name = "wallet")
		private float wallet;
		
		@Column(name ="phone")
		private Long phone;
		
		public Long getPhone() {
			return phone;
		}
		public void setPhone(Long phone) {
			this.phone = phone;
		}
		public float getWallet() {
			return wallet;
		}
		public void setWallet(float wallet) {
			this.wallet = wallet;
		}
		public Customer(Long id, String custFirstName, String custEmail, String custLastName, String custAddress,
				String password, Float wallet,Long phone) {
			super();
			this.id = id;
			this.custFirstName = custFirstName;
			this.custEmail = custEmail;
			this.custLastName = custLastName;
			this.custAddress = custAddress;
			this.password = password;
			this.wallet = wallet;
			this.phone = phone;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public Customer(Long id, String custFirstName, String custEmail, String custLastName, String custAddress) {
			super();
			this.id = id;
			this.custFirstName = custFirstName;
			this.custEmail = custEmail;
			this.custLastName = custLastName;
			this.custAddress = custAddress;
		}
		public Customer(Long id) {
			super();
			this.id = id;
		}
		public String getCustFirstName() {
			return custFirstName;
		}
		public void setCustFirstName(String custFirstName) {
			this.custFirstName = custFirstName;
		}
		public String getCustEmail() {
			return custEmail;
		}
		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}
		public String getCustLastName() {
			return custLastName;
		}
		public void setCustLastName(String custLastName) {
			this.custLastName = custLastName;
		}
		public String getCustAddress() {
			return custAddress;
		}
		public void setCustAddress(String custAddress) {
			this.custAddress = custAddress;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getId() {
			return id;
		}

		}
