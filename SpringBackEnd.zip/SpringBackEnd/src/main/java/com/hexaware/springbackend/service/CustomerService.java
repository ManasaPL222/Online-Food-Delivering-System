package com.hexaware.springbackend.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.hexaware.springbackend.entity.Customer;
import com.hexaware.springbackend.exception.CustomerNotFoundException;

public interface CustomerService {

	List<Customer> getAllCustomers();
	
	Customer createCustomer(Customer newCustomer);

	public ResponseEntity<Customer> getCustomerById(Long custId) throws CustomerNotFoundException;

	ResponseEntity<Map<String,Boolean>>  deleteCustomer(Long custId)throws CustomerNotFoundException;

	ResponseEntity<Customer>  updateCustomer(Customer newCustomer, Long id) throws CustomerNotFoundException;

	//login validation
	ResponseEntity<Customer>  loginCustomer(String email)throws CustomerNotFoundException;

	ResponseEntity<Customer> updateWallet(Long id, Float wallet);

	ResponseEntity<Customer> updatePwd(Long id, String pwd);
	
}
