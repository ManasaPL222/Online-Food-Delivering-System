package com.hexaware.springbackend.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.hexaware.springbackend.entity.Cart;
import com.hexaware.springbackend.exception.CartNotFoundException;

public interface CartService {
	
	List<Cart> cartItems();
	
	Cart insertCart(Cart newCart);

	public ResponseEntity<Cart> getCartById(Long cartId) throws CartNotFoundException;

	ResponseEntity<Map<String,Boolean>>  deleteCartById(Long cartId)throws CartNotFoundException;

	public ResponseEntity<Cart> updateCart(Cart updateCart, Long cartId) throws CartNotFoundException;

	List<Cart> findBycustId(Long custId) throws CartNotFoundException;

	


}
