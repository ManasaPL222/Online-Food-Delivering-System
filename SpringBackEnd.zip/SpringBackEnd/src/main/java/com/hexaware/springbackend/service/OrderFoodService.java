package com.hexaware.springbackend.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.hexaware.springbackend.entity.OrderFood;

public interface OrderFoodService {

	OrderFood createOrder(OrderFood newOrd);

	Optional<OrderFood> getOrderById(Long ordId);

	List<OrderFood> getAllOrders();

	ResponseEntity<Map<String, Boolean>> deleteOrder(Long ordId);

	ResponseEntity<OrderFood> updateOrder(OrderFood updateOrder, Long id);
	
	List<OrderFood> ordBycustId(Long custId);
	
	List<OrderFood> findByrestId(Long restId);

}
