package com.hexaware.springbackend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hexaware.springbackend.entity.Customer;
import com.hexaware.springbackend.exception.CustomerNotFoundException;
import com.hexaware.springbackend.exception.RestaurantNotFoundException;
import com.hexaware.springbackend.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerRepository custRepository;

	@Override
	public Customer createCustomer(Customer newCustomer) {
		// TODO Auto-generated method stub
		return custRepository.save(newCustomer);
	}

	@Override
	public ResponseEntity<Customer> getCustomerById(Long custId) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer customer = custRepository.findById(custId).orElseThrow(()-> new CustomerNotFoundException("Customer Not Found with id: " +custId));
				return ResponseEntity.ok(customer);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteCustomer(Long custId) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer delCustomer = custRepository.findById(custId).
				orElseThrow(() -> new CustomerNotFoundException("Customer does not exist with id = " + custId));
		custRepository.delete(delCustomer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);

	}

	@Override
	public ResponseEntity<Customer> updateCustomer(Customer updateCustomer, Long id) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer customer = custRepository.findById(id).
				orElseThrow(() -> new CustomerNotFoundException("Customer does not exist with id = " + id));
		customer.setCustEmail(updateCustomer.getCustEmail());
		customer.setCustFirstName(updateCustomer.getCustFirstName());
		customer.setCustLastName(updateCustomer.getCustLastName());
		customer.setCustAddress(updateCustomer.getCustAddress());
		customer.setPassword(updateCustomer.getPassword());
		customer.setWallet(updateCustomer.getWallet());
		customer.setPhone(updateCustomer.getPhone());
		Customer updatedCustomer = custRepository.save(customer);
		return ResponseEntity.ok(updatedCustomer);
	}

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return custRepository.findAll();
	}

	@Override
	public ResponseEntity<Customer> loginCustomer(String email) throws CustomerNotFoundException {
		// TODO Auto-generated method stub
		Customer customer= custRepository.findBycustEmail(email).
				orElseThrow(() -> new RestaurantNotFoundException("Customer does not exist with email = " + email));
		return ResponseEntity.ok(customer);
	}

	@Override
	public ResponseEntity<Customer> updateWallet(Long id, Float wallet) {
		// TODO Auto-generated method stub
		Customer customer = custRepository.findById(id).
				orElseThrow(() -> new CustomerNotFoundException("Customer does not exist with id = " + id));
		customer.setWallet(wallet);
		Customer updatedCustomer = custRepository.save(customer);
		return ResponseEntity.ok(updatedCustomer);
	}

	@Override
	public ResponseEntity<Customer> updatePwd(Long id, String pwd) {
		// TODO Auto-generated method stub
		Customer customer = custRepository.findById(id).
				orElseThrow(() -> new CustomerNotFoundException("Customer does not exist with id = " + id));
		customer.setPassword(pwd);
		Customer updatedCustomer = custRepository.save(customer);
		return ResponseEntity.ok(updatedCustomer);
	}

}
