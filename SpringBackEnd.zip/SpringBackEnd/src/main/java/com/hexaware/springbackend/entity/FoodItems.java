package com.hexaware.springbackend.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class FoodItems {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long foodId;
	
	@Column(name ="restName")
	private String restName;
	
	@Column (name ="restId")
	private Long restId;
	
	public FoodItems(String restName, String foodName, String foodType, Long foodQuan, float foodPrice) {
		super();
		this.restName = restName;
		this.foodName = foodName;
		this.foodType = foodType;
		this.foodQuan = foodQuan;
		this.foodPrice = foodPrice;
	}

	public Long getRestId() {
		return restId;
	}

	public void setRestId(Long restId) {
		this.restId = restId;
	}

	public FoodItems(Long restId,Long foodId, String restName, String foodName, String foodType, Long foodQuan, float foodPrice) {
		super();
		this.restId = restId;
		this.foodId = foodId;
		this.restName = restName;
		this.foodName = foodName;
		this.foodType = foodType;
		this.foodQuan = foodQuan;
		this.foodPrice = foodPrice;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	@Column(name ="foodName")
	private String foodName;
	
	@Column(name = "foodType")
	private String foodType;
	
	@Column(name ="foodQuan")
	private Long foodQuan;
	
	@Column(name ="foodPrice")
	private float foodPrice;

	
	public Long getFoodId() {
		return foodId;
	}

	public void setFoodId(Long foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public Long getFoodQuan() {
		return foodQuan;
	}

	public void setFoodQuan(Long foodQuan) {
		this.foodQuan = foodQuan;
	}

	public float getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(float foodPrice) {
		this.foodPrice = foodPrice;
	}

	public FoodItems() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
