package com.hexaware.springbackend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.hexaware.springbackend.entity.FoodItems;
import com.hexaware.springbackend.exception.FoodItemNotFoundException;
import com.hexaware.springbackend.repository.FoodItemRepository;

@Service
public class FoodItemServiceImpl implements FoodItemService {

	@Autowired
	private FoodItemRepository foodRepository;
	
	@Override
	public List<FoodItems> getAllFoodItems() {
		// TODO Auto-generated method stub
		return foodRepository.findAll();
	}

	@Override
	public FoodItems createFoodItem(FoodItems newFoodItem) {
		// TODO Auto-generated method stub
		return foodRepository.save(newFoodItem);
	}

	@Override
	public ResponseEntity<FoodItems> getFoodItemById(Long foodId) throws FoodItemNotFoundException {
		// TODO Auto-generated method stub
		FoodItems fooditem = foodRepository.findById(foodId).orElseThrow(()-> new FoodItemNotFoundException("FoodItem with id "+foodId+" does not exist  = "));
		return ResponseEntity.ok(fooditem);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteFoodItem(Long foodId) throws FoodItemNotFoundException {
		// TODO Auto-generated method stub
		FoodItems delfoodItem= foodRepository.findById(foodId).
				orElseThrow(() -> new FoodItemNotFoundException("Food Item does not exist with id = " + foodId));
		foodRepository.delete(delfoodItem);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	@Override
	public ResponseEntity<FoodItems> updateFoodItem(FoodItems updateFoodItem, Long id)
			throws FoodItemNotFoundException {
		// TODO Auto-generated method stub
		FoodItems foodItem = foodRepository.findById(id).
				orElseThrow(() -> new FoodItemNotFoundException("Food Item does not exist with id = " + id));
		foodItem.setFoodName(updateFoodItem.getFoodName());
		foodItem.setFoodType(updateFoodItem.getFoodType());
		foodItem.setFoodPrice(updateFoodItem.getFoodPrice());
		foodItem.setFoodQuan(updateFoodItem.getFoodQuan());
		
		FoodItems updatedFoodItem = foodRepository.save(foodItem);
		return ResponseEntity.ok(updatedFoodItem);
	}

	@Override
	public List<FoodItems> findByrestId(Long id){
		
//		return null;
		return foodRepository.findByrestId(id);
				
	}


}
