package com.hexaware.springbackend.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import com.hexaware.springbackend.exception.FoodItemNotFoundException;
import com.hexaware.springbackend.entity.FoodItems;

public interface FoodItemService {

	List<FoodItems> getAllFoodItems();
	
	FoodItems createFoodItem(FoodItems newFoodItems);

	public ResponseEntity<FoodItems> getFoodItemById(Long foodId) throws FoodItemNotFoundException;
	
	ResponseEntity<Map<String,Boolean>>  deleteFoodItem(Long foodId)throws FoodItemNotFoundException;

	ResponseEntity<FoodItems>  updateFoodItem(FoodItems updateFoodItem, Long id) throws FoodItemNotFoundException;

	List<FoodItems> findByrestId(Long id);
}