package com.hexaware.springbackend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hexaware.springbackend.entity.FoodItems;
import com.hexaware.springbackend.exception.FoodItemNotFoundException;

@Repository
public interface FoodItemRepository extends JpaRepository<FoodItems, Long> {

	List<FoodItems> findByrestId(Long id);
}
