package com.hexaware.springbackend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.hexaware.springbackend.entity.OrderFood;
import com.hexaware.springbackend.exception.OrderNotFoundException;
import com.hexaware.springbackend.repository.OrderFoodRepository;


@Service
public class OrderFoodServiceImpl implements OrderFoodService {

	@Autowired
	private OrderFoodRepository ordRepo;
	
	@Override
	public OrderFood createOrder(OrderFood newOrd) {
		// TODO Auto-generated method stub
		return ordRepo.save(newOrd);
	}

	@Override
	public Optional<OrderFood> getOrderById(Long ordId) {
		// TODO Auto-generated method stub
		return ordRepo.findById(ordId);
	}

	@Override
	public List<OrderFood> getAllOrders() {
		// TODO Auto-generated method stub
		return ordRepo.findAll();
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteOrder(Long ordId) {
		// TODO Auto-generated method stub
		OrderFood order = ordRepo.findById(ordId)
				.orElseThrow(() -> new OrderNotFoundException("Order does not exist with id = " + ordId));
		ordRepo.delete(order);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	@Override
	public ResponseEntity<OrderFood> updateOrder(OrderFood updateOrder, Long id) {
		// TODO Auto-generated method stub
		OrderFood order = ordRepo.findById(id).
				orElseThrow(() -> new OrderNotFoundException("Order does not exist with id = " + id));
		order.setStatus(updateOrder.getStatus());
//		order.setCustId(updateOrder.getCustId());
		OrderFood upOrder = ordRepo.save(order);
		return ResponseEntity.ok(upOrder);
	}

	@Override
	public List<OrderFood> ordBycustId(Long custId) {
		// TODO Auto-generated method stub
		return ordRepo.findBycustId(custId);
	}

	@Override
	public List<OrderFood> findByrestId(Long id) {
		// TODO Auto-generated method stub
		return ordRepo.findByrestId(id);
	}

}
