package com.hexaware.springbackend.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Restaurant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long restId;
	
	@Column(name = "restName")
	private String restName;
	
	@Column(name="restEmail")
	private String restEmail;
	
	@Column(name ="restContact")
	private Long restContact;
	
	@Column(name ="restAddress")
	private String restAddress;
	
	@Column(name ="password")
	private String password;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Restaurant(String restName, String restEmail, Long restContact, String restAddress) {
		super();
		this.restName = restName;
		this.restEmail = restEmail;
		this.restContact = restContact;
		this.restAddress = restAddress;
	}
	

	public Restaurant(Long restId, String restName, String restEmail, Long restContact, String restAddress) {
		super();
		this.restId = restId;
		this.restName = restName;
		this.restEmail = restEmail;
		this.restContact = restContact;
		this.restAddress = restAddress;
	}

	public Restaurant(Long restId, String restName, String restEmail, Long restContact, String restAddress, String password) {
		super();
		this.restId = restId;
		this.restName = restName;
		this.restEmail = restEmail;
		this.restContact = restContact;
		this.restAddress = restAddress;
		this.password = password;
	}
	
	

	public Restaurant() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getRestId() {
		return restId;
	}

	public void setRestId(Long restId) {
		this.restId = restId;
	}

	public String getRestName() {
		return restName;
	}

	public void setRestName(String restName) {
		this.restName = restName;
	}

	public String getRestEmail() {
		return restEmail;
	}

	public void setRestEmail(String restEmail) {
		this.restEmail = restEmail;
	}

	public Long getRestContact() {
		return restContact;
	}

	public void setRestContact(Long restContact) {
		this.restContact = restContact;
	}

	public String getRestAddress() {
		return restAddress;
	}

	public void setRestAddress(String restAddress) {
		this.restAddress = restAddress;
	}
	
	
}	