package com.hexaware.springbackend.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.hexaware.springbackend.entity.Restaurant;
import com.hexaware.springbackend.exception.CustomerNotFoundException;
import com.hexaware.springbackend.exception.RestaurantNotFoundException;
import com.hexaware.springbackend.repository.RestaurantRepository;

@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	private RestaurantRepository restRepository; 

	
	@Override
	public List<Restaurant> getAllRestaurants() {
		// TODO Auto-generated method stub
		return restRepository.findAll();
	}

	@Override
	public Restaurant createRestaurant(Restaurant newRestaurant) {
		// TODO Auto-generated method stub
		return restRepository.save(newRestaurant);
	}

	@Override
	public ResponseEntity<Restaurant> getRestaurantById(Long restId) throws RestaurantNotFoundException {
		// TODO Auto-generated method stub
		Restaurant restaurant = restRepository.findById(restId).orElseThrow(()-> new CustomerNotFoundException("Customer Not Found with id: " +restId));
		return ResponseEntity.ok(restaurant);
	}

	@Override
	public ResponseEntity<Map<String, Boolean>> deleteRestaurant(Long restId) throws RestaurantNotFoundException {
		// TODO Auto-generated method stub
		Restaurant delRestaurant= restRepository.findById(restId).
				orElseThrow(() -> new RestaurantNotFoundException("Restaurant does not exist with id = " + restId));
		restRepository.delete(delRestaurant);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);

	}

	@Override
	public ResponseEntity<Restaurant> updateRestaurant(Restaurant upRestaurant, Long id)
			throws RestaurantNotFoundException {
		// TODO Auto-generated method stub
		Restaurant restaurant = restRepository.findById(id).
				orElseThrow(() -> new RestaurantNotFoundException("Restaurant does not exist with id = " + id));
		restaurant.setRestEmail(upRestaurant.getRestEmail());
		restaurant.setRestName(upRestaurant.getRestName());
		restaurant.setRestContact(upRestaurant.getRestContact());
		restaurant.setRestAddress(upRestaurant.getRestAddress());
		
		Restaurant updatedRestaurant = restRepository.save(restaurant);
		return ResponseEntity.ok(updatedRestaurant);
	}


	@Override
	public ResponseEntity<Restaurant> loginRestaurant(String email)throws RestaurantNotFoundException{
		// TODO Auto-generated method stub
		Restaurant restaurant= restRepository.findByrestEmail(email)
				.orElseThrow(() -> new RestaurantNotFoundException("Restaurant does not exist with email = " + email));
		return ResponseEntity.ok(restaurant);
	}

	@Override
	public Optional<Restaurant> findByrestEmail(String email) throws RestaurantNotFoundException {
		// TODO Auto-generated method stub
		return restRepository.findByrestEmail(email);
	}


}
